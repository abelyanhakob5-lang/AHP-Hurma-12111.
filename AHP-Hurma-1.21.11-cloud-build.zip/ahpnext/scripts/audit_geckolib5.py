#!/usr/bin/env python3
"""Static migration audit for GeckoLib 5 / Minecraft 1.21.11.
This is intentionally a source audit, not a substitute for Gradle compilation.
Run from the project root: python3 scripts/audit_geckolib5.py
"""
from pathlib import Path
import re
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOTS = [ROOT / "common/src/main/java", ROOT / "fabric/src/main/java"]
PATTERNS = {
    "legacy GeoModel renderer-parameter signature": re.compile(r"get(Model|Texture)Resource\s*\([^)]*GeoRenderer<"),
    "legacy GeoRenderer generic arity": re.compile(r"extends\s+Geo(?:EntityRenderer|RenderLayer|BlockRenderer)<[^,<>]+>"),
    "legacy renderer preRender hook": re.compile(r"\bpreRender\s*\("),
    "legacy renderer renderFinal hook": re.compile(r"\brenderFinal\s*\("),
    "legacy entity-instance render callback": re.compile(r"public\s+void\s+render\s*\(\s*HamsterEntity\s+entity\s*,\s*float\s+entityYaw"),
    "legacy entity texture hook": re.compile(r"\bgetTextureLocation\s*\(\s*HamsterEntity\s+"),
    "legacy GeckoLib package namespace": re.compile(r"software\.bernie\.geckolib"),
    "legacy AnimationState model hook": re.compile(r"setCustomAnimations\s*\("),
    "legacy GeoBone animation processor usage": re.compile(r"getAnimationProcessor\s*\(\)"),
    "legacy layer render callback": re.compile(r"public\s+void\s+render\s*\(\s*MatrixStack\s+poseStack\s*,\s*HamsterEntity"),
    "legacy render-type callback": re.compile(r"getRenderType\s*\(\s*HamsterBedBlockEntity\s+"),
    "legacy one-argument GeoRenderer subclass": re.compile(r"extends\s+Geo(?:EntityRenderer|RenderLayer|BlockRenderer)<[^,<>]+>"),
}
files = []
for root in JAVA_ROOTS:
    if root.exists():
        files.extend(root.rglob("*.java"))
print("GeckoLib 5 static audit — this does NOT compile the project")
print(f"Java files scanned: {len(files)}")
for label, pattern in PATTERNS.items():
    hits = []
    for path in files:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            continue
        for n, line in enumerate(lines, 1):
            if pattern.search(line):
                hits.append(f"  {path.relative_to(ROOT)}:{n}: {line.strip()}")
    print(f"\n[{label}] {len(hits)} hit(s)")
    print("\n".join(hits[:30]) if hits else "  none")
    if len(hits) > 30:
        print(f"  ... {len(hits) - 30} more")


# Catch a common source-edit regression that regex API checks do not detect:
# an @Override separated from its method declaration or immediately duplicated.
override_errors = []
for path in files:
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    for i, line in enumerate(lines):
        if line.strip() != "@Override":
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines) or lines[j].lstrip().startswith("//") or lines[j].strip() == "@Override":
            override_errors.append(f"  {path.relative_to(ROOT)}:{i + 1}: dangling or duplicated @Override")
print(f"\n[Java annotation sanity] {len(override_errors)} issue(s)")
print("\\n".join(override_errors) if override_errors else "  none")
asset_root = ROOT / "common/src/main/resources/assets/adorablehamsterpets"
expected = [
    "geckolib/models/hamster.geo.json",
    "geckolib/models/hamster_bed.geo.json",
    "geckolib/animations/anim_hamster.animation.json",
    "geckolib/animations/anim_hamster_bed.animation.json",
]
print("\n[GeckoLib 5 model/animation asset paths]")
for rel in expected:
    print(("OK   " if (asset_root / rel).is_file() else "MISS ") + rel)



# Yarn 1.21.11 class names (the accessor method is still getEntityRenderDispatcher).
yarn_name_errors = []
for path in files:
    source = path.read_text(encoding="utf-8", errors="ignore")
    if re.search(r"import\s+net\.minecraft\.client\.render\.(?:entity\.EntityRenderDispatcher|block\.entity\.BlockEntityRenderDispatcher)\s*;", source):
        yarn_name_errors.append(f"  {path.relative_to(ROOT)}: imports a dispatcher class name removed from Yarn 1.21.11")
print(f"\n[Yarn renderer class names] {len(yarn_name_errors)} issue(s)")
print("\\n".join(yarn_name_errors) if yarn_name_errors else "  none")

# Verify the attachment migration by behavior, not by the absence of old helper names.
renderer_path = ROOT / "common/src/main/java/net/dawson/adorablehamsterpets/entity/client/HamsterRenderer.java"
attachment_path = ROOT / "common/src/main/java/net/dawson/adorablehamsterpets/entity/client/HamsterAttachmentRenderLayer.java"
renderer_text = renderer_path.read_text(encoding="utf-8", errors="ignore") if renderer_path.exists() else ""
attachment_text = attachment_path.read_text(encoding="utf-8", errors="ignore") if attachment_path.exists() else ""
item_attachment_wired = (
    "HamsterAttachmentRenderLayer" in renderer_text
    and 'getBone("nose")' in attachment_text
    and "getHeldItemRenderer().renderItem" in attachment_text
    and "addPerBoneRender" in attachment_text
)
passenger_attachment_wired = (
    'getBone("body_child")' in attachment_text
    and "getEntityRenderDispatcher" in attachment_text
    and "EntityRenderManager" in attachment_text
    and "getAndUpdateRenderState" in attachment_text
)
print("\n[Attachment render tasks]")
print(("OK   " if item_attachment_wired else "MISS ") + "mouth item submitted as a deferred nose-bone task")
print(("OK   " if passenger_attachment_wired else "BLOCKED ") + "passengers submitted as deferred body_child-bone tasks")



# Legacy mixins targeting removed immediate-render methods must stay disabled until reimplemented.
mixin_config_path = ROOT / "common/src/main/resources/adorablehamsterpets.mixins.json"
try:
    mixin_config_data = json.loads(mixin_config_path.read_text(encoding="utf-8"))
except Exception:
    mixin_config_data = {}
active_client_mixins = set(mixin_config_data.get("client", []))
legacy_render_mixins_active = any(name in active_client_mixins for name in (
    "client.EntityRenderDispatcherMixin", "client.BlockEntityRenderDispatcherMixin"
))
print("\n[Legacy immediate-render mixins]")
print(("BLOCKED " if legacy_render_mixins_active else "OK      ") + "obsolete renderShadow/block-entity render mixins are not active")

# Verify the passenger duplicate-render guard targets the post-1.21.5 render-state API.
mixin_path = ROOT / "common/src/main/java/net/dawson/adorablehamsterpets/mixin/client/LivingEntityRendererMixin.java"
mixin_text = mixin_path.read_text(encoding="utf-8", errors="ignore") if mixin_path.exists() else ""
legacy_mixin_target = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V" in mixin_text
current_mixin_target = (
    "@Mixin(EntityRenderer.class)" in mixin_text
    and "shouldRender(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/Frustum;DDD)Z" in mixin_text
    and "CallbackInfoReturnable<Boolean>" in mixin_text
)
print("\n[Passenger duplicate-render guard]")
print(("BLOCKED " if legacy_mixin_target else "OK      ") + "legacy immediate-render mixin target removed")
print(("OK      " if current_mixin_target else "BLOCKED ") + "visibility guard targets EntityRenderer.shouldRender in 1.21.11")

# Non-zero exit in CI/local checks when any known migration blocker remains.
if "--strict" in sys.argv:
    blockers = (
        "legacy GeoRenderer generic arity",
        "legacy renderer preRender hook",
        "legacy renderer renderFinal hook",
        "legacy entity-instance render callback",
        "legacy entity texture hook",
        "legacy AnimationState model hook",
        "legacy GeoBone animation processor usage",
        "legacy layer render callback",
        "legacy render-type callback",
        "legacy one-argument GeoRenderer subclass",
    )
    # Re-scan counts rather than parsing formatted stdout.
    found = []
    if not item_attachment_wired:
        found.append("mouth item per-bone render task is not wired")
    if not passenger_attachment_wired:
        found.append("passenger per-bone render task is not implemented")
    if yarn_name_errors:
        found.append("Yarn renderer class name mismatch")
    if legacy_mixin_target or not current_mixin_target:
        found.append("passenger duplicate-render mixin target is not migrated to 1.21.11")
    if legacy_render_mixins_active:
        found.append("legacy immediate-render mixins are still active")
    for label in blockers:
        pattern = PATTERNS.get(label)
        if pattern and any(pattern.search(line) for path in files for line in path.read_text(encoding="utf-8", errors="ignore").splitlines()):
            found.append(label)
    if found:
        print("\nSTRICT RESULT: BLOCKED — remaining GeckoLib 5 migration markers:")
        print("\n".join(f"- {label}" for label in found))
        sys.exit(1)
    print("\nSTRICT RESULT: no known static markers found (still not a compile/test).")
