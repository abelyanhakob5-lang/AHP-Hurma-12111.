# AHP + «Дядя Гриша» — перенос на Minecraft Java 1.21.11 (Fabric)

## Что подготовлено в этом черновике
- Целевая версия Minecraft: `1.21.11`, Java 21.
- Yarn mappings: `1.21.11+build.6`.
- Fabric API: `0.141.6+1.21.11` (существование версии проверено в официальном Maven Fabric).
- GeckoLib: `5.4.4` (опубликованная Fabric-версия для Minecraft 1.21.11; `5.4.5` в предыдущем черновике не подтверждена).
- Fzzy Config: `0.7.7+1.21.11`.
- Iris compile-only: `1.10.7+1.21.11`.
- Проект настроен как Fabric-only, чтобы сосредоточиться на целевой платформе.
- Добавлены Hurma: четыре варианта корма, эффекты зачарованного золотого яблока для хомяка, приручение одной единицей корма, команда `/hamster summon`, спавн в деревнях, яйца спавна и встроенный торговец.

## Блокеры, которые не разрешены
1. **Patchouli**: найден неофициальный Fabric-порт для Minecraft 1.21.11 — Patchouli: Fabric Edition 1.21.11-94.4, CurseForge file ID `8713841`. Gradle-конфигурация обновлена на этот артефакт. Порт неофициальный и лицензирован CC BY-NC-SA 3.0; перед публичным распространением нужно учитывать атрибуцию, ShareAlike и запрет коммерческого использования. Внутренние классы Patchouli остаются нестабильным API и должны быть проверены компиляцией/запуском.
2. **GeckoLib 4 → 5**: версия библиотеки обновлена, но вызовы API в 16 Java-файлах ссылаются на старую библиотеку и должны быть адаптированы и проверены компилятором.
3. **Minecraft/Fabric API**: все Java-классы и mixin targets должны быть скомпилированы против 1.21.11; статическая смена версий не подтверждает их совместимость.
4. **Необязательные интеграции**: Accessories/Trinkets/Jade и mixins требуют проверки на целевой версии.
5. **Проверка в игре**: сохранение хомяков, shoulder feature, корм, трейды, спавн в деревнях и команда пока не подтверждены запуском игры.

## Изменения этого прохода
- Переключена зависимость Patchouli на опубликованный Fabric-порт для 1.21.11: `curse.maven:patchouli-fabric-edition-1664943:8713841`.
- В `fabric.mod.json` убрана жёсткая нижняя граница версии Patchouli, привязанная к выпуску для 1.21.1; мод по-прежнему объявляет Patchouli зависимостью.
- Это устраняет заведомо неправильный артефакт в Gradle-конфигурации, но не подтверждает совместимость внутренних Patchouli API и mixin targets.

## Проверка сборки
В этой среде Gradle ранее не смог загрузить дистрибутив с `services.gradle.org` из-за сетевого DNS-ограничения. Поэтому `.jar` не собран, а компиляция Java-кода не подтверждена. Этот архив — исходный проект для продолжения порта, не готовый мод.

## Источники версий
- Fabric API 0.141.6+1.21.11: https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/0.141.6%2B1.21.11/
- GeckoLib 5.4.4 для Fabric 1.21.11: https://modrinth.com/mod/geckolib/version/5.4.4
- Iris 1.10.7+1.21.11 Fabric: https://modrinth.com/mod/iris/version/1.10.7%2B1.21.11-fabric
- Список совместимости Patchouli: https://www.curseforge.com/minecraft/mc-mods/patchouli-fabric-edition/files/8713841

## Дополнительный проход: GeckoLib 5 — миграция ресурсов
- Перенесены 2 геометрические модели из `assets/adorablehamsterpets/geo/` в `assets/adorablehamsterpets/geckolib/models/`.
- Перенесены 2 файла анимаций в `assets/adorablehamsterpets/geckolib/animations/`.
- Пути в `HamsterModel`, `HamsterBedModel` и `HamsterBedItemModel` переведены на логические идентификаторы GeckoLib 5 без старых префиксов и суффиксов.
- Это исправляет структуру ресурсов для GeckoLib 5, но не является завершением API-порта: Java-рендереры и модели всё ещё используют часть GeckoLib 4 сигнатур.

## Дополнительная техническая карта

Подробная разбивка по конкретным Java-файлам и несовместимым GeckoLib 5 API находится в `GECKOLIB5_MIGRATION_MAP_RU.md`. Она уточняет, какие участки нельзя исправить простой заменой импортов, и задаёт порядок компиляционных/игровых проверок.

## Следующие обязательные задачи
1. Переписать GeckoLib `GeoModel`, renderer и render-layer классы под `GeoRenderState` и новые generic-типы.
2. Перенести обработчики кастомных анимаций с `AnimationState` на API GeckoLib 5 (`AnimationTest` для предикатов контроллеров).
3. Проверить рендеринг слоёв/глаз и отрисовку хомяка на плече — код использует кастомную геометрию и состояние сущности.
4. Обновить/изолировать необязательные интеграции Jade, Accessories и Trinkets для доступных версий 1.21.11.
5. После восстановления загрузки Gradle выполнить `compileJava`, `remapJar` и тестовый запуск клиента/сервера.

## Последний проход: статический аудит GeckoLib 5
- Добавлен `scripts/audit_geckolib5.py`, который воспроизводимо перечисляет оставшиеся вызовы старого API, не утверждая, что это компиляционная проверка.
- Результат сохранён в `GECKOLIB5_AUDIT_LATEST_RU.txt`.
- По текущему аудиту остаются: 6 старых сигнатур `GeoModel`, 4 старых generic-сигнатуры renderer/layer, 2 старых hook-метода renderer, 1 старый `getTextureLocation(HamsterEntity)`, 1 старый импорт `AnimationState` и 1 обращение к `getAnimationProcessor()`.
- Подтверждено наличие 4 основных GeckoLib 5 ресурсов по новым путям.
- Версия GeckoLib 5.4.4 проверена как опубликованная сборка Fabric для Minecraft 1.21.11: https://modrinth.com/mod/geckolib/version/5.4.4.
- Компиляция всё ещё не выполнена из-за недоступности загрузки Gradle; этот аудит не доказывает совместимость Java-кода.


## Последний аудит (2026-10-12)
Скрипт `scripts/audit_geckolib5.py` запущен на 339 Java-файлах. Он обнаружил:
- 6 старых сигнатур `GeoModel` с параметрами animatable/renderer;
- 4 старых объявления renderer с generic-типом GeckoLib 4;
- 2 старых render hooks (`preRender`, `renderFinal`);
- 1 старый `getTextureLocation`;
- 1 импорт `software.bernie.geckolib.animation.AnimationState`;
- 1 использование старого `getAnimationProcessor()` для доступа к костям.
Пути 4 основных geo/animation JSON-файлов существуют в структуре GeckoLib 5.

Это аудит исходников, а не исправление всех этих API. Следующая задача — миграция Java-классов рендеринга и моделей по одному, с последующей компиляцией против GeckoLib 5. До доступной компиляции не следует делать массовые предположительные замены сигнатур: они могут скрыть одни ошибки и добавить другие.
Полный вывод: `GECKOLIB5_AUDIT_LATEST_RU.txt`.

## Продолжение переноса: первые сигнатуры GeoModel GeckoLib 5
- В `HamsterModel`, `HamsterBedModel` и `HamsterBedItemModel` заменены старые методы `getModelResource(animatable, renderer)` / `getTextureResource(animatable, renderer)` на сигнатуры GeckoLib 5, принимающие `GeoRenderState`.
- Удалены старые compatibility-overloads `getModelResource(animatable)` и `getTextureResource(animatable)`, которые делегировали в уже удалённые старые сигнатуры.
- Для модели лежанки задана безопасная oak-текстура по умолчанию: вариант дерева должен быть перенесён в render-state ticket при миграции `HamsterBedRenderer`.
- Повторный статический аудит теперь не находит старые `GeoModel` методы с параметром `GeoRenderer`.

**Не завершено:** `HamsterModel` по-прежнему содержит старый `setCustomAnimations`/`getAnimationProcessor`; entity renderer, render layer и renderer лежанки требуют полноценного переноса на render-state API. Эти изменения пока нельзя считать собранными или проверенными: Gradle всё ещё недоступен в среде.


## Продолжение: перенос namespace GeckoLib 5
- Во всех 16 Java-файлах, использовавших GeckoLib, заменён старый корневой package `software.bernie.geckolib` на `com.geckolib`, соответствующий исходникам GeckoLib 5.
- Импорты `BakedGeoModel` и `GeoBone` переведены на новый пакет `com.geckolib.cache.model`.
- Обновлён статический аудит, чтобы ловить остатки старого namespace и старый `setCustomAnimations`.

**Остался серьёзный блокер:** у GeckoLib 5 изменена модель рендеринга. Одной смены namespace недостаточно. `HamsterModel.setCustomAnimations` и `getAnimationProcessor()` нельзя считать перенесёнными; нужно перепроектировать кастомные изменения костей через render-state/поддерживаемые hooks. Аналогично `HamsterRenderer`, render layers, shoulder renderer и рендереры лежанки всё ещё используют старые render hooks и Minecraft render API. Компиляция не запускалась, так что этот проход — частичная миграция исходников, не готовый мод.

## Самый свежий проход: строгий аудит render-state API
- Обновлён `scripts/audit_geckolib5.py`: добавлены проверки старых callbacks слоя/рендеринга, старой арности `GeoRenderer` и поддержка `--strict`.
- Запуск `python3 scripts/audit_geckolib5.py --strict` сейчас корректно завершается с кодом 1, потому что известные несовместимости остаются. Это намеренный сигнал, а не ошибка самого скрипта.
- Конкретные блокеры и рекомендуемый порядок исправлений записаны в `GECKOLIB5_NEXT_STEPS_RU.md`.
- Java-код в этом проходе не объявляется перенесённым: render-state миграция требует менять сигнатуры и сохранять все текущие визуальные функции. Компиляция по-прежнему не выполнена.


## Дополнительный проход (12 октября 2026)

- Исправлена Gradle-зависимость Trinkets: вместо `dev.emi:trinkets:3.10.0` (ветка для 1.21.1) используется опубликованный артефакт Trinkets Updated для Minecraft 1.21.11 (`maven.modrinth:XaT8sLP6:DHE2OnLP`).
- Это устраняет один заведомо устаревший compile-only артефакт, но не подтверждает успешную сборку: Gradle и зависимости всё ещё невозможно скачать в текущей среде из-за DNS.
- Интеграция Accessories пока остаётся отдельным блокером: проект использует версию API для 1.21.1; для 1.21.11 нужно подтвердить совместимый артефакт/сигнатуры, а не просто менять номер версии.
- Главные незавершённые задачи GeckoLib 5 остаются: миграция `HamsterModel`/`HamsterRenderer`, `RedstoneFeverEyesRenderLayer`, рендереров лежанки и последующая компиляция/игровые тесты.
