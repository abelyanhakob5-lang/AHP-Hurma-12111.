# Следующий этап миграции GeckoLib 5

## Что изменено в этом проходе

- Перенесён перехват дублирующей отрисовки пассажиров с удалённого немедленного `LivingEntityRenderer.render(LivingEntity, ...)` на `EntityRenderer.shouldRender(Entity, Frustum, double, double, double)` из Minecraft 1.21.11.
- Проверка работает на уровне диспетчера видимости: обычный проход не рисует сущность, которая едет на хомяке; слой хомяка напрямую отправляет её render state в очередь отрисовки на кости `body_child`.
- Размер тени детёныша записывается в `LivingEntityRenderState`, а не в общий экземпляр рендерера. Это предотвращает утечку радиуса тени между разными хомяками.
- Статический аудит теперь проверяет целевой метод mixin и обнаруживает возврат к старому дескриптору `render(LivingEntity, ...)`.

## Ограничения проверки

Строгий статический аудит не является заменой Gradle-компиляции или теста в клиенте. До успешной сборки нельзя считать порт завершённым; нужно проверить сигнатуры GeckoLib 5, запуск клиента и фактическую отрисовку пассажира и предмета у носа.


## Новое: Yarn renderer class names and obsolete mixins

- Corrected Yarn 1.21.11 class names to `EntityRenderManager` / `BlockEntityRenderManager` while retaining `MinecraftClient.getEntityRenderDispatcher()`.
- Disabled two obsolete immediate-render mixins in `adorablehamsterpets.mixins.json` until their injections can be migrated to render-state/command-queue hooks. This avoids mandatory mixin failures, but temporarily removes hamster roll-shadow offset and block-entity jiggle.
- Strict static audit passes; this is not compile verification.
