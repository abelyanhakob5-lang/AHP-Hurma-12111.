# Hamster feed behavior

The four feed items (`hamster_feed_classic`, `hamster_feed_forest`, `hamster_feed_fire`, `hamster_feed_golden`) intentionally have no edible/consumable component. Players cannot eat them directly. The feed is consumed only through `HamsterEntity.interactMob` when the player uses it on a hamster.

- Wild hamster: one feed item tames it for the interacting player, then applies the effects below.
- Tamed hamster: only its owner can feed it; one item is consumed and the effects are applied.
- Creative mode: item count is not reduced, matching normal creative-mode item behavior.
- Player: no status effects are applied to the player.

Effects applied to the hamster, matching the vanilla enchanted golden apple:

- Regeneration II — 20 seconds
- Resistance I — 5 minutes
- Fire Resistance I — 5 minutes
- Absorption IV — 2 minutes

The project is still based on the Minecraft 1.21.1 API. This document describes the source implementation; it is not a claim that the mod has been compiled or tested in-game.
