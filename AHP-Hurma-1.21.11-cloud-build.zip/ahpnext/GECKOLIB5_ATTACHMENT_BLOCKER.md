# GeckoLib 5: attachment rendering status

## Implemented in this pass

`HamsterAttachmentRenderLayer` now registers deferred per-bone tasks for both attachments:

- `nose`: snapshots a copy of the mouth `ItemStack` in render state and submits it using Minecraft 1.21.11's `HeldItemRenderer.renderItem` and `ItemDisplayContext.THIRD_PERSON_RIGHT_HAND`.
- `body_child`: snapshots the passenger list and submits each living passenger through `EntityRenderManager` / `EntityRenderer.getAndUpdateRenderState` / `EntityRenderer.render`, using the current per-bone pose and camera state. The code retains first-person suppression, seat offsets, mount-scale compensation, and suppresses rider shadows.

The previous immediate-render helper methods that depended on `VertexConsumerProvider` and the pre-render-state entity render call have been removed.

## Verification status

`scripts/audit_geckolib5.py --strict` passes its static checks, including explicit checks that both attachment tasks are registered. This is not a Java compile or an in-game test.

A compile attempt with `bash gradlew :common:compileJava` stops before Gradle starts because this environment cannot resolve `services.gradle.org` (`UnknownHostException`). Consequently, API linkage and visual behavior remain unverified until the project can be built with its dependencies available.

## Follow-up tests needed

1. Compile against Fabric 1.21.11 + Yarn build.6 + GeckoLib 5.4.4.
2. Test multiple passengers, player first-person view, baby/adult hamster scaling, and rider shadows.
3. Test mouth items with flat, block, and custom item models.
4. Test shoulder rendering independently to ensure it doesn't emit world particles or keyframe sounds.
