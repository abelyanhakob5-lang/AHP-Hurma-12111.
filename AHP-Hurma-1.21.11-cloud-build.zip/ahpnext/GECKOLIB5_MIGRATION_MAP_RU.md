# Карта переноса GeckoLib 4 → 5 (Fabric / Minecraft 1.21.11)

Это рабочий технический список, а не отметка о завершённом переносе. По официальной документации GeckoLib 5 renderer больше не может читать Entity/BlockEntity на этапе отрисовки: нужные данные нужно извлечь заранее в `GeoRenderState` через render-data tickets.

## 1. Модели: заменить методы GeoModel

Старые методы, которые получают animatable и `GeoRenderer`, больше не соответствуют GeckoLib 5:
- `entity/client/HamsterModel.java`
- `block/client/HamsterBedModel.java`
- `item/client/HamsterBedItemModel.java`

Нужны `getModelResource(GeoRenderState)`, `getTextureResource(GeoRenderState)` и `getAnimationResource(GeoRenderState)`. Для хомяка и лежанки динамические параметры (вариант текстуры, цвет/состояние, возраст, броня, щёки, цветок, поворот и т. п.) необходимо передать в render state до отрисовки. Простая замена сигнатур сломает динамическое поведение.

## 2. Основной renderer хомяка — большой блокер

`entity/client/HamsterRenderer.java` использует старый `GeoEntityRenderer` API, методы `preRender`/`renderFinal`, `BakedGeoModel`, `VertexConsumerProvider`, отслеживание костей и ручную отрисовку пассажиров/предметов/частиц/звуков. GeckoLib 5 и Minecraft 1.21.11 используют новую render-state и submit-node модель. Требуется поэтапно переписать renderer, сохранив:
- пассажиров на кости `seat`;
- предмет у носа;
- эффекты keyframe;
- смещение по поверхности и дрожание;
- режим производительности;
- отображение хомяка на плече.

## 3. Render layers / плечо

Проверить и мигрировать:
- `entity/client/RedstoneFeverEyesRenderLayer.java`
- `entity/client/feature/HamsterShoulderFeatureRenderer.java`
- `entity/client/renderer/ShoulderHamsterRenderer.java`
- `entity/client/feature/ShoulderAnimationState.java`
- `entity/client/feature/ShoulderHamsterState.java`

У слоёв теперь новые generic-типы с `GeoRenderState`. Данные сущности для плечевого рендера должны быть скопированы в render state, а не читаться из entity во время фактического submit/render.

## 4. Лежанка и предмет

Проверить:
- `block/client/HamsterBedRenderer.java`
- `block/client/HamsterBedItemRenderer.java`
- `block/entity/HamsterBedBlockEntity.java`
- `item/custom/HamsterBedItem.java`

Для блока и предмета необходимо сохранить текущую текстуру/вариант древесины и контроллер анимации. В GeckoLib 5 обновились пакеты классов и сигнатуры рендера.

## 5. Контроллеры анимации и диагностика

Проверить импорты/предикаты:
- `entity/custom/animation/HamsterAnimationController.java`
- `entity/custom/HamsterEntity.java`
- `integration/jade/HamsterDebugComponentProvider.java`

Предикаты контроллеров в GeckoLib 5 используют `AnimationTest`, а не старую форму `AnimationState`. Учитывая объём пользовательских анимаций, механическая замена типов без тестов недостаточна.

## 6. Проверка

В этой среде запуск `./gradlew --version` остановился до загрузки Gradle с `UnknownHostException: services.gradle.org`. Поэтому ни один пункт нельзя считать подтверждённым компилятором. После появления сети/готового Gradle-дистрибутива нужно выполнить:

1. `./gradlew :common:compileJava :fabric:compileJava`
2. `./gradlew :fabric:remapJar`
3. запуск Minecraft 1.21.11 с Fabric Loader и тест мира;
4. отдельные тесты сущности, анимаций, лежанки, плеча, корма, трейдера и команды.

## Статус

Модели и анимационные JSON перемещены в каталоги GeckoLib 5, но Java API-перенос НЕ завершён. Архив остаётся исходным черновиком, а не готовым `.jar`.
