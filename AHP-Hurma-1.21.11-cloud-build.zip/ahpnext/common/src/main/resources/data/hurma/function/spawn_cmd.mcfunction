# tick.mcfunction decrements cooldowns later in this same server tick; +1 keeps the full 6000-tick cooldown.
scoreboard players set @s hurma_cd 6001
function hurma:summon
tag @e[type=minecraft:wandering_trader,tag=hurma_new] remove hurma_new
tellraw @s {text:"Дядя Гриша пришёл!",color:"gold"}
