scoreboard players set @s hurma 0
execute if score @s hurma_cd matches 1.. run tellraw @s {text:"Дядя Гриша отдыхает, подожди немного!",color:"red"}
execute unless score @s hurma_cd matches 1.. run function hurma:spawn_cmd
