# Lock the current interval BEFORE spawning; this runs synchronously for each player.
scoreboard players set #global hurma_spawned 1
function hurma:summon
spreadplayers ~ ~ 1 24 false @e[type=minecraft:wandering_trader,tag=hurma_new,limit=1]
tag @e[type=minecraft:wandering_trader,tag=hurma_new] remove hurma_new
tellraw @s {text:"Где-то рядом бродит Дядя Гриша с хурмой!",color:"gold"}
