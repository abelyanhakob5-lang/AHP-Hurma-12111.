# Used by the Uncle Grisha spawn egg: same trader and trades as /trigger hurma, without cooldown/messages
function hurma:summon
tag @e[type=minecraft:wandering_trader,tag=hurma_new] remove hurma_new
