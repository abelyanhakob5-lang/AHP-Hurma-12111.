# One roll per 10-minute interval. The flag is set inside spawn_random before summoning,
# so later players in this same execute-as pass cannot trigger another spawn.
scoreboard players set #global hurma_t 0
scoreboard players set #global hurma_spawned 0
execute as @a[gamemode=!spectator] at @s if score #global hurma_spawned matches 0 if predicate hurma:overworld if predicate hurma:chance unless entity @e[type=minecraft:wandering_trader,tag=hurma_trader,distance=..100] run function hurma:spawn_random
