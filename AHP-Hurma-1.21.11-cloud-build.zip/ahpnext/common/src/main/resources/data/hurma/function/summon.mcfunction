summon minecraft:wandering_trader ~ ~ ~ {CustomName:{text:"Дядя Гриша продавец всякой хурмой",color:"gold"},CustomNameVisible:1b,PersistenceRequired:1b,Tags:["hurma_trader","hurma_new"],Offers:{Recipes:[]}}
execute as @e[type=minecraft:wandering_trader,tag=hurma_new,limit=1] run function hurma:trades
execute as @e[type=minecraft:wandering_trader,tag=hurma_new,limit=1] run function hurma:dirt_trades
