scoreboard objectives add hurma trigger
scoreboard objectives add hurma_cd dummy
scoreboard objectives add hurma_t dummy
scoreboard objectives add hurma_spawned dummy
