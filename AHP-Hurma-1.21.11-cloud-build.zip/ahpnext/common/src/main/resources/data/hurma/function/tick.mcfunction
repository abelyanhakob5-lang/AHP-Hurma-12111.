# команда /trigger hurma для всех игроков (работает без читов)
scoreboard players enable @a hurma
execute as @a[scores={hurma=1..}] at @s run function hurma:call
scoreboard players remove @a[scores={hurma_cd=1..}] hurma_cd 1
# случайный спавн: раз в 10 минут (12000 тиков)
scoreboard players add #global hurma_t 1
execute if score #global hurma_t matches 12000.. run function hurma:roll
