package net.dawson.adorablehamsterpets.entity.client;

import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.AdorableHamsterPetsClient;
import net.dawson.adorablehamsterpets.config.Configs;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.dawson.adorablehamsterpets.item.ModItems;
import net.dawson.adorablehamsterpets.item.custom.HamsterArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.model.GeoModel;
import com.geckolib.renderer.base.BoneSnapshots;
import com.geckolib.renderer.base.GeoRenderState;
import com.geckolib.animation.state.BoneSnapshot;


@SuppressWarnings("removal")
public class HamsterModel extends GeoModel<HamsterEntity> {

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Constants
     * ────────────────────────────────────────────────────────────────────────────*/

    private static final float ADULT_SCALE = 0.8f;
    private static final float ADULT_HEAD_SCALE = 1.0f;
    private static final float BABY_SCALE = 0.5f;
    private static final float BABY_HEAD_SCALE = 1.2f;

    public static final DataTicket<HamsterEntity> HAMSTER_ENTITY =
            DataTicket.create("adorablehamsterpets_hamster_entity_snapshot", HamsterEntity.class);

    private static final String[] CUSTOM_BONES = {
            "root", "body_parent", "body_child", "head_parent",
            "left_cheek_deflated", "right_cheek_deflated", "left_cheek_inflated", "right_cheek_inflated",
            "right_ear", "acorn_hat", "flower_head_no_armor", "flower_side_no_armor",
            "flower_lower_back_no_armor", "flower_head_with_armor", "flower_side_with_armor",
            "flower_lower_back_with_armor", "upper_eye_lid", "lower_eye_lid"
    };

    private static final Identifier MODEL_RESOURCE = Identifier.of(AdorableHamsterPets.MOD_ID, "hamster");
    private static final Identifier ANIMATION_RESOURCE = Identifier.of(AdorableHamsterPets.MOD_ID, "anim_hamster");
    private static final Identifier FALLBACK_TEXTURE = Identifier.of(AdorableHamsterPets.MOD_ID, "textures/entity/hamster/fur_base_pattern/fur_pattern.png");

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Overrides
     * ────────────────────────────────────────────────────────────────────────────*/

    @Override
    public Identifier getModelResource(GeoRenderState renderState) {
        return MODEL_RESOURCE;
    }

    @Override
    public Identifier getTextureResource(GeoRenderState renderState) {
        // Fallback texture; actual texture handled by renderer
        return FALLBACK_TEXTURE;
    }

    @Override
    public Identifier getAnimationResource(HamsterEntity animatable) {
        return ANIMATION_RESOURCE;
    }

    @Override
    public void addAdditionalStateData(HamsterEntity entity, Object relatedObject, GeoRenderState renderState) {
        super.addAdditionalStateData(entity, relatedObject, renderState);
        // GeckoLib 5 renders from a snapshot. The entity reference is only used during
        // this synchronous model-adjustment pass to preserve the existing procedural rules.
        renderState.addGeckolibData(HAMSTER_ENTITY, entity);
    }

    public void adjustModelBones(HamsterEntity entity, BoneSnapshots snapshots) {
        if (entity == null) {
            return;
        }

        // --- Performance Mode ---
        if (AdorableHamsterPetsClient.isPerformanceModeEnabled) {
            // Hide everything except absolute essentials
            for (String name : CUSTOM_BONES) {
                BoneSnapshot bone = bone(snapshots, name);
                if (bone != null) {
                    boolean keepVisible = name.equals("root")
                            || name.equals("body_parent")
                            || name.equals("body_child");
                    bone.skipRender(!keepVisible);
                }
            }

            return; // Skip all other visual calculations
        } else {
            // Restore visibility to all bones when performance mode off
            for (String name : CUSTOM_BONES) {
                BoneSnapshot bone = bone(snapshots, name);
                if (bone != null) {
                    bone.skipRender(false);
                }
            }
        }

        // --- Normal Mode ---
        // --- Bone References ---
        var rootBone = bone(snapshots, "root");
        var headParentBone = bone(snapshots, "head_parent");
        var leftCheekDefBone = bone(snapshots, "left_cheek_deflated");
        var rightCheekDefBone = bone(snapshots, "right_cheek_deflated");
        var leftCheekInfBone = bone(snapshots, "left_cheek_inflated");
        var rightCheekInfBone = bone(snapshots, "right_cheek_inflated");
        var rightEarBone = bone(snapshots, "right_ear");
        var acornHatBone = bone(snapshots, "acorn_hat");
        var flowerHeadNoArmorBone = bone(snapshots, "flower_head_no_armor");
        var flowerSideNoArmorBone = bone(snapshots, "flower_side_no_armor");
        var flowerBackNoArmorBone = bone(snapshots, "flower_lower_back_no_armor");
        var flowerHeadWithArmorBone = bone(snapshots, "flower_head_with_armor");
        var flowerSideWithArmorBone = bone(snapshots, "flower_side_with_armor");
        var flowerBackWithArmorBone = bone(snapshots, "flower_lower_back_with_armor");

        // --- Statue / AI Disabled Logic ---
        // Ensure eyes remain open in t-pose
        var upperEyeLidBone = bone(snapshots, "upper_eye_lid");
        if (upperEyeLidBone != null) {
            upperEyeLidBone.skipRender(entity.isAiDisabled());
        }
        var lowerEyeLidBone = bone(snapshots, "lower_eye_lid");
        if (lowerEyeLidBone != null) {
            lowerEyeLidBone.skipRender(entity.isAiDisabled());
        }

        // --- Easter Egg Logic ---
        boolean isMoonwalking = entity.isMoonwalking();

        // --- Equipment State ---
        ItemStack armorStack = entity.getArmorStack();
        boolean isArmorVisible = Configs.AHP_MAIN.enableArmorVisuals
                && entity.isArmorVisible()
                && !armorStack.isEmpty()
                && armorStack.getItem() instanceof HamsterArmorItem;

        // --- Pink Petal Logic ---
        int flowerType = entity.getDataTracker().get(HamsterEntity.FLOWER_POS);
        boolean useArmorFlowers = isArmorVisible && Configs.AHP_MAIN.renderFlowersWithArmor.get();

        if (flowerHeadNoArmorBone != null) flowerHeadNoArmorBone.skipRender(flowerType != 1 || useArmorFlowers);
        if (flowerSideNoArmorBone != null) flowerSideNoArmorBone.skipRender(flowerType != 2 || useArmorFlowers);
        if (flowerBackNoArmorBone != null) flowerBackNoArmorBone.skipRender(flowerType != 3 || useArmorFlowers);

        if (flowerHeadWithArmorBone != null) flowerHeadWithArmorBone.skipRender(flowerType != 1 || !useArmorFlowers);
        if (flowerSideWithArmorBone != null) flowerSideWithArmorBone.skipRender(flowerType != 2 || !useArmorFlowers);
        if (flowerBackWithArmorBone != null) flowerBackWithArmorBone.skipRender(flowerType != 3 || !useArmorFlowers);

        // --- Cheek Pouch Logic ---
        if (leftCheekDefBone != null && leftCheekInfBone != null) {
            boolean leftFull = entity.isLeftCheekFull();
            leftCheekDefBone.skipRender(leftFull);
            leftCheekInfBone.skipRender(!leftFull);
        }
        if (rightCheekDefBone != null && rightCheekInfBone != null) {
            boolean rightFull = entity.isRightCheekFull();
            rightCheekDefBone.skipRender(rightFull);
            rightCheekInfBone.skipRender(!rightFull);
        }

        // --- Armor/Accessory Logic ---
        if (rightEarBone != null) {
            boolean shouldHideEar = false;
            boolean shouldShowHat = false;

            // Check bling slot 6 for highest priority
            ItemStack blingStack = entity.getAccessoryStack();
            if (blingStack.isOf(ModItems.ACORN_HAT.get())) {
                shouldHideEar = true; // Prevent clipping through hat
                shouldShowHat = true;
            }

            // Check armor slot 7 and config if not already showing hat
            if (!shouldShowHat
                    && isArmorVisible
                    && armorStack.isOf(ModItems.HAMSTER_ARMOR_ACORN.get())
                    && Configs.AHP_MAIN.renderAcornHat.get()) {
                shouldHideEar = true;
                shouldShowHat = true;
            }

            rightEarBone.skipRender(shouldHideEar);

            if (acornHatBone != null) {
                acornHatBone.skipRender(!shouldShowHat);
            }
        }

        // --- Scaling & Rotation Logic ---
        // bodyParentBone scale intentionally not set here so json breathing anims scale proportionally
        if (rootBone != null && headParentBone != null) {
            // Calculate continuous growth progress (0.0 = newborn, 1.0 = adult)
            float ageProgress = 1.0f;
            if (entity.isBaby()) {
                int exactAge = entity.getDataTracker().get(HamsterEntity.EXACT_AGE);
                ageProgress = 1.0f - (Math.abs(exactAge) / 24000.0f);
            }

            // Smoothly lerp between baby and adult scales
            float currentBaseScale = MathHelper.lerp(ageProgress, BABY_SCALE, ADULT_SCALE);
            float currentHeadScale = MathHelper.lerp(ageProgress, BABY_HEAD_SCALE, ADULT_HEAD_SCALE);

            rootBone.setScale(currentBaseScale, rootBone.getScaleY(), currentBaseScale);
            

            // Override y scale for dynamic squash and stretch if shoulder pet
            if (entity.isShoulderPet()) {
                rootBone.setScale(currentBaseScale, currentBaseScale * entity.dynamicScaleY, currentBaseScale);
            } else {
                rootBone.setScale(currentBaseScale, currentBaseScale, currentBaseScale);
            }

            headParentBone.setScale(currentHeadScale, currentHeadScale, currentHeadScale);

            float pitchOffset = 0.0f;

            // --- Dynamic Pitch Rotation ---
            if (entity.clientFluteMountFlight) {
                float partialTick = 1.0f;
                pitchOffset = MathHelper.lerp(
                        partialTick,
                        entity.prevClientFluteMountPitch,
                        entity.clientFluteMountPitch);
            } else if (entity.isFluteMountFlight()) {
                pitchOffset = entity.getFluteMountPitch();
            } else if (entity.isProjectileDummy) {
                // --- Projectile Mode ---
                // Align with velocity vector (follow flight arc)
                Vec3d velocity = entity.getVelocity();
                double horizontalSpeed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);

                // Calculate pitch: Positive RotX = Nose Up, Negative RotX = Nose Down
                pitchOffset = (float) Math.atan2(velocity.y, horizontalSpeed);
            } else if (entity.isTouchingWater() || entity.isInLava()) {
                // --- Swim Mode ---
                // Use pre-smoothed pitch to eliminate buoyancy RNG flickering
                float partialTick = 1.0f;
                pitchOffset = MathHelper.lerp(partialTick, entity.prevClientSwimPitch, entity.clientSwimPitch);
            } else if (entity.clientFallPitchProgress > 0.0f || entity.prevClientFallPitchProgress > 0.0f) {
                float partialTick = 1.0f;
                float lerpedProgress = MathHelper.lerp(partialTick, entity.prevClientFallPitchProgress, entity.clientFallPitchProgress);

                // Natural Fall Mode: Procedural Nose Dive (Cosine Interpolation)
                float interpolated = (1.0f - MathHelper.cos(lerpedProgress * (float) Math.PI)) * 0.5f;

                // Rotate to face downward
                pitchOffset = (float) (-Math.PI / 2.0) * interpolated;
            }

            // Absolute assignment
            rootBone.setRotation(pitchOffset, rootBone.getRotY(), rootBone.getRotZ());

            // Easter Egg rotation if applicable
            if (isMoonwalking) {
                rootBone.setRotation(rootBone.getRotX(), (float) Math.PI, rootBone.getRotZ());
            } else {
                rootBone.setRotation(rootBone.getRotX(), 0.0f, rootBone.getRotZ());
            }
        }
    }


    private static BoneSnapshot bone(BoneSnapshots snapshots, String name) {
        return snapshots.get(name).orElse(null);
    }

}
