package net.dawson.adorablehamsterpets.util;

import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Handles hamster-specific melee range and owner-combat exclusions.
 */
public final class HamsterCombatUtil {

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Constants
     * ────────────────────────────────────────────────────────────────────────────*/

    private static final double ATTACK_BOX_EXPANSION = 0.70D;
    private static final int OWNER_EVENT_FRESHNESS_TICKS = 100;
    private static final long STANDARD_COMBAT_DURATION_TICKS = 600L;

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Static Utilities
     * ────────────────────────────────────────────────────────────────────────────*/

    public static boolean isInAttackRange(HamsterEntity hamster, LivingEntity target) {
        Box attackBox =
                hamster.getBoundingBox().expand(ATTACK_BOX_EXPANSION, 0.0D, ATTACK_BOX_EXPANSION);
        return attackBox.intersects(target.getBoundingBox());
    }

    public static StandardCombatState createStandardCombatState() {
        return new StandardCombatState();
    }

    public static boolean isStandardCombatEngaged(HamsterEntity hamster) {
        if (!usesStandardCombatWindow(hamster)) {
            return false;
        }

        LivingEntity target = hamster.getTarget();
        StandardCombatState state = hamster.getStandardCombatState();
        return isConflictEngaged(
                target == null ? null : target.getUuid(),
                state.targetUuid,
                hamster.getWorld().getTime(),
                state.deadline);
    }

    public static boolean deescalateStandardCombat(HamsterEntity hamster) {
        if (hamster.getWorld().isClient() || !isStandardCombatEngaged(hamster)) {
            return false;
        }

        LivingEntity target = hamster.getTarget();
        StandardCombatState state = hamster.getStandardCombatState();
        if (target != null) {
            refreshFromOwnerCombat(hamster, target);
        }

        UUID conflictUuid = target == null ? state.targetUuid : target.getUuid();
        LivingEntity owner = hamster.getOwner();
        int ownerAttackTime = owner == state.observedOwner
                ? state.consumedOwnerAttackTime
                : owner == null ? Integer.MIN_VALUE : owner.getLastAttackTime();
        int ownerAttackedTime = owner == state.observedOwner
                ? state.consumedOwnerAttackedTime
                : owner == null ? Integer.MIN_VALUE : owner.getLastAttackedTime();
        LivingEntity attacker = hamster.getAttacker();
        boolean conflictMatchesRetaliation =
                attacker != null && attacker.getUuid().equals(conflictUuid);
        int hamsterAttackedTime = conflictMatchesRetaliation
                ? hamster.getLastAttackedTime()
                : state.consumedHamsterAttackedTime;

        hamster.setTarget(null);
        hamster.getNavigation().stop();
        if (conflictMatchesRetaliation) {
            hamster.setAttacker(null);
        }

        clearActiveCombatWindow(state);
        state.expiredTargetUuid = conflictUuid;
        state.expiredOwner = owner;
        state.expiredOwnerAttackTime = ownerAttackTime;
        state.expiredOwnerAttackedTime = ownerAttackedTime;
        state.expiredHamsterAttackedTime = hamsterAttackedTime;
        return true;
    }

    public static boolean canAttackWithOwner(
            HamsterEntity hamster, LivingEntity target, LivingEntity owner) {
        if (!isTargetLegal(hamster, target) || !isFreshOwnerConflict(owner, target)) {
            return false;
        }
        return !isSuppressedConflict(hamster, target);
    }

    public static boolean canAcquireTarget(HamsterEntity hamster, LivingEntity target) {
        return isTargetLegal(hamster, target) && !isSuppressedConflict(hamster, target);
    }

    public static boolean canContinueTarget(HamsterEntity hamster, @Nullable LivingEntity target) {
        if (target == null || !isTargetLegal(hamster, target)) {
            return false;
        }
        if (!usesStandardCombatWindow(hamster)) {
            return hamster.getAggressionState() != HamsterEntity.AggressionState.PACIFIST;
        }

        StandardCombatState state = hamster.getStandardCombatState();
        return state.targetUuid != null
                && state.targetUuid.equals(target.getUuid())
                && hamster.getWorld().getTime() < state.deadline;
    }

    public static boolean clearInvalidTarget(HamsterEntity hamster) {
        LivingEntity target = hamster.getTarget();
        if (target == null || canContinueTarget(hamster, target)) {
            return false;
        }

        terminateStandardCombat(hamster, false);
        return true;
    }

    public static void acceptTarget(
            HamsterEntity hamster,
            @Nullable LivingEntity previousTarget,
            @Nullable LivingEntity acceptedTarget) {
        if (hamster.getWorld().isClient()) {
            return;
        }
        if (acceptedTarget == null) {
            if (!usesStandardCombatWindow(hamster)) {
                clearStandardCombatState(hamster);
            }
            return;
        }
        if (!usesStandardCombatWindow(hamster)) {
            clearStandardCombatState(hamster);
            return;
        }

        StandardCombatState state = hamster.getStandardCombatState();
        if (previousTarget == acceptedTarget && acceptedTarget.getUuid().equals(state.targetUuid)) {
            refreshFromOwnerCombat(hamster, acceptedTarget);
            return;
        }

        LivingEntity owner = hamster.getOwner();
        state.targetUuid = acceptedTarget.getUuid();
        state.deadline = hamster.getWorld().getTime() + STANDARD_COMBAT_DURATION_TICKS;
        state.observedOwner = owner;
        state.consumedOwnerAttackTime = owner == null ? Integer.MIN_VALUE : owner.getLastAttackTime();
        state.consumedOwnerAttackedTime =
                owner == null ? Integer.MIN_VALUE : owner.getLastAttackedTime();
        state.consumedHamsterAttackedTime = hamster.getLastAttackedTime();
        state.expiredTargetUuid = null;
        state.expiredOwner = null;
    }

    public static void tickStandardCombat(HamsterEntity hamster) {
        if (hamster.getWorld().isClient()) {
            return;
        }
        if (hamster.hasRedstoneFever()) {
            // Dedicated fever goals replace ordinary aggression state
            clearStandardCombatState(hamster);
            return;
        }

        LivingEntity target = hamster.getTarget();
        if (target != null && !isTargetLegal(hamster, target)) {
            terminateStandardCombat(hamster, false);
            return;
        }

        if (!usesStandardCombatWindow(hamster)) {
            if (hamster.getAggressionState() != HamsterEntity.AggressionState.STANDARD) {
                clearStandardCombatState(hamster);
            }
            return;
        }

        if (target == null) {
            StandardCombatState state = hamster.getStandardCombatState();
            if (state.targetUuid != null && hamster.getWorld().getTime() >= state.deadline) {
                terminateStandardCombat(hamster, true);
            }
            return;
        }

        refreshFromOwnerCombat(hamster, target);
        if (hamster.getWorld().getTime() >= hamster.getStandardCombatState().deadline) {
            terminateStandardCombat(hamster, true);
        }
    }

    public static void handleAggressionStateChange(
            HamsterEntity hamster,
            HamsterEntity.AggressionState previousState,
            HamsterEntity.AggressionState newState) {
        if (hamster.getWorld().isClient() || previousState == newState) {
            return;
        }
        if (newState == HamsterEntity.AggressionState.MENACE) {
            clearStandardCombatState(hamster);
            return;
        }
        if (newState == HamsterEntity.AggressionState.PACIFIST
                || previousState == HamsterEntity.AggressionState.MENACE) {
            terminateStandardCombat(hamster, false);
        }
    }

    public static void terminateStandardCombat(HamsterEntity hamster) {
        terminateStandardCombat(hamster, false);
    }

    public static void clearStandardCombatState(HamsterEntity hamster) {
        StandardCombatState state = hamster.getStandardCombatState();
        clearActiveCombatWindow(state);
        state.expiredTargetUuid = null;
        state.expiredOwner = null;
        state.expiredOwnerAttackTime = Integer.MIN_VALUE;
        state.expiredOwnerAttackedTime = Integer.MIN_VALUE;
        state.expiredHamsterAttackedTime = Integer.MIN_VALUE;
    }

    private static boolean isTargetLegal(HamsterEntity hamster, LivingEntity target) {
        if (!target.isAlive()
                || target.isRemoved()
                || hamster.getAggressionState() == HamsterEntity.AggressionState.PACIFIST) {
            return false;
        }

        LivingEntity owner = hamster.getOwner();
        if (target == hamster || target == owner || target instanceof CreeperEntity
                || target instanceof ArmorStandEntity) {
            return false;
        }
        UUID ownerUuid = hamster.getOwnerUuid();
        if (ownerUuid == null) {
            return true;
        }

        AdorableHamsterPets.LOGGER.trace(
                "[canAttackWithOwner] Hamster: {}, Target: {}, Owner: {}",
                hamster.getName().getString(),
                target.getName().getString(),
                owner == null ? ownerUuid : owner.getName().getString());

        UUID targetOwnerUuid = PetOwnershipUtil.resolveTargetOwnerUuid(target);
        if (ownerUuid.equals(targetOwnerUuid)) {
            AdorableHamsterPets.LOGGER.trace(
                    "[canAttackWithOwner] Target belongs to the hamster owner. Preventing attack.");
            return false;
        }
        return !isAcornRingContractProtected(hamster, ownerUuid, targetOwnerUuid);
    }

    private static boolean isAcornRingContractProtected(
            HamsterEntity hamster, UUID hamsterOwnerUuid, @Nullable UUID targetOwnerUuid) {
        if (targetOwnerUuid == null
                || targetOwnerUuid.equals(hamsterOwnerUuid)
                || !(hamster.getWorld() instanceof ServerWorld serverWorld)) {
            return false;
        }

        ServerPlayerEntity hamsterOwner =
                serverWorld.getServer().getPlayerManager().getPlayer(hamsterOwnerUuid);
        ServerPlayerEntity targetOwner =
                serverWorld.getServer().getPlayerManager().getPlayer(targetOwnerUuid);
        return hamsterOwner != null
                && targetOwner != null
                && isContractProtected(
                        hamsterOwnerUuid,
                        targetOwnerUuid,
                        AcornRingUtil.isEquipped(hamsterOwner),
                        AcornRingUtil.isEquipped(targetOwner));
    }

    static boolean isContractProtected(
            UUID hamsterOwnerUuid,
            UUID targetOwnerUuid,
            boolean hamsterOwnerEquipped,
            boolean targetOwnerEquipped) {
        return AcornRingUtil.isContractProtected(
                hamsterOwnerUuid,
                targetOwnerUuid,
                hamsterOwnerEquipped,
                targetOwnerEquipped);
    }

    private static boolean isFreshOwnerConflict(LivingEntity owner, LivingEntity target) {
        boolean freshOwnerAttack =
                target == owner.getAttacking()
                        && owner.age - owner.getLastAttackTime() <= OWNER_EVENT_FRESHNESS_TICKS;
        boolean freshOwnerAttacker =
                target == owner.getAttacker()
                        && owner.age - owner.getLastAttackedTime() <= OWNER_EVENT_FRESHNESS_TICKS;
        return freshOwnerAttack || freshOwnerAttacker;
    }

    private static boolean isSuppressedConflict(HamsterEntity hamster, LivingEntity target) {
        if (!usesStandardCombatWindow(hamster)) {
            return false;
        }

        StandardCombatState state = hamster.getStandardCombatState();
        if (!target.getUuid().equals(state.expiredTargetUuid)) {
            return false;
        }

        LivingEntity owner = hamster.getOwner();
        if (owner != null && owner != state.expiredOwner) {
            return !isFreshOwnerConflict(owner, target);
        }
        if (owner != null) {
            if (target == owner.getAttacking()
                    && owner.getLastAttackTime() > state.expiredOwnerAttackTime) {
                return false;
            }
            if (target == owner.getAttacker()
                    && owner.getLastAttackedTime() > state.expiredOwnerAttackedTime) {
                return false;
            }
        }
        return target != hamster.getAttacker()
                || hamster.getLastAttackedTime() <= state.expiredHamsterAttackedTime;
    }

    private static void refreshFromOwnerCombat(HamsterEntity hamster, LivingEntity target) {
        StandardCombatState state = hamster.getStandardCombatState();
        LivingEntity owner = hamster.getOwner();
        if (owner == null || !owner.isAlive()) {
            return;
        }
        if (owner != state.observedOwner) {
            state.observedOwner = owner;
            state.consumedOwnerAttackTime = owner.getLastAttackTime();
            state.consumedOwnerAttackedTime = owner.getLastAttackedTime();
            return;
        }

        boolean refreshed = false;
        if (target == owner.getAttacking()
                && owner.getLastAttackTime() > state.consumedOwnerAttackTime) {
            state.consumedOwnerAttackTime = owner.getLastAttackTime();
            refreshed = true;
        }
        if (target == owner.getAttacker()
                && owner.getLastAttackedTime() > state.consumedOwnerAttackedTime) {
            state.consumedOwnerAttackedTime = owner.getLastAttackedTime();
            refreshed = true;
        }
        if (refreshed) {
            state.deadline = hamster.getWorld().getTime() + STANDARD_COMBAT_DURATION_TICKS;
        }
    }

    private static boolean usesStandardCombatWindow(HamsterEntity hamster) {
        return hamster.isTamed()
                && hamster.getAggressionState() == HamsterEntity.AggressionState.STANDARD;
    }

    static boolean isConflictEngaged(
            @Nullable UUID currentTargetUuid,
            @Nullable UUID windowTargetUuid,
            long currentTick,
            long deadline) {
        return currentTargetUuid != null
                || windowTargetUuid != null && currentTick < deadline;
    }

    private static void terminateStandardCombat(HamsterEntity hamster, boolean suppressConflict) {
        LivingEntity target = hamster.getTarget();
        StandardCombatState state = hamster.getStandardCombatState();
        UUID expiredTargetUuid = suppressConflict
                ? target == null ? state.targetUuid : target.getUuid()
                : null;
        LivingEntity expiredOwner = suppressConflict
                ? state.observedOwner == null ? hamster.getOwner() : state.observedOwner
                : null;
        int expiredOwnerAttackTime = expiredOwner == null
                ? Integer.MIN_VALUE
                : expiredOwner == state.observedOwner
                        ? state.consumedOwnerAttackTime
                        : expiredOwner.getLastAttackTime();
        int expiredOwnerAttackedTime = expiredOwner == null
                ? Integer.MIN_VALUE
                : expiredOwner == state.observedOwner
                        ? state.consumedOwnerAttackedTime
                        : expiredOwner.getLastAttackedTime();
        int expiredHamsterAttackedTime = hamster.getLastAttackedTime();

        hamster.setTarget(null);
        hamster.getNavigation().stop();
        if (target != null && target == hamster.getAttacker()) {
            hamster.setAttacker(null);
        }
        clearActiveCombatWindow(state);
        if (suppressConflict && expiredTargetUuid != null) {
            state.expiredTargetUuid = expiredTargetUuid;
            state.expiredOwner = expiredOwner;
            state.expiredOwnerAttackTime = expiredOwnerAttackTime;
            state.expiredOwnerAttackedTime = expiredOwnerAttackedTime;
            state.expiredHamsterAttackedTime = expiredHamsterAttackedTime;
        } else {
            clearStandardCombatState(hamster);
        }
    }

    private static void clearActiveCombatWindow(StandardCombatState state) {
        state.targetUuid = null;
        state.deadline = Long.MIN_VALUE;
        state.observedOwner = null;
        state.consumedOwnerAttackTime = Integer.MIN_VALUE;
        state.consumedOwnerAttackedTime = Integer.MIN_VALUE;
        state.consumedHamsterAttackedTime = Integer.MIN_VALUE;
    }

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Constructors
     * ────────────────────────────────────────────────────────────────────────────*/

    private HamsterCombatUtil() {}

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Nested Types
     * ────────────────────────────────────────────────────────────────────────────*/

    public static final class StandardCombatState {
        @Nullable private UUID targetUuid;
        private long deadline = Long.MIN_VALUE;
        @Nullable private LivingEntity observedOwner;
        private int consumedOwnerAttackTime = Integer.MIN_VALUE;
        private int consumedOwnerAttackedTime = Integer.MIN_VALUE;
        private int consumedHamsterAttackedTime = Integer.MIN_VALUE;
        @Nullable private UUID expiredTargetUuid;
        @Nullable private LivingEntity expiredOwner;
        private int expiredOwnerAttackTime = Integer.MIN_VALUE;
        private int expiredOwnerAttackedTime = Integer.MIN_VALUE;
        private int expiredHamsterAttackedTime = Integer.MIN_VALUE;

        private StandardCombatState() {}
    }
}
