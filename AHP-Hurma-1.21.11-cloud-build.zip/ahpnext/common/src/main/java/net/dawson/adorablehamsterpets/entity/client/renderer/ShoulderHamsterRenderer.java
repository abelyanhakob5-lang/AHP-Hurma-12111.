package net.dawson.adorablehamsterpets.entity.client.renderer;

import net.dawson.adorablehamsterpets.entity.client.HamsterRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;

/**
 * Renderer for the cosmetic shoulder-mounted hamster.
 *
 * GeckoLib 5 uses the same render-state pipeline for shoulder and world rendering.
 * Shoulder-specific transform/effect suppression is handled by HamsterRenderer using
 * the hamster's captured state instead of overriding the removed entity render callback.
 */
public class ShoulderHamsterRenderer extends HamsterRenderer {
    public ShoulderHamsterRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }
}
