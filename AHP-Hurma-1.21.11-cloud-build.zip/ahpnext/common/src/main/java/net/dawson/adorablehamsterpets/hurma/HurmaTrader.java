package net.dawson.adorablehamsterpets.hurma;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/**
 * Bridge to the trader logic that lives INSIDE this mod's jar as built-in data
 * ({@code data/hurma/function/*.mcfunction}, always enabled, no separate datapack to install).
 *
 * <p>The functions are run with the server's own command source at a fixed, hard-coded function id.
 * No player input is ever turned into a command, so this grants no operator rights and cannot be
 * used to run arbitrary commands.
 */
public final class HurmaTrader {

    private HurmaTrader() {}

    /** Summons the trader exactly like the datapack does (same name, tag, offers) at {@code pos}. */
    public static boolean spawnEgg(ServerWorld world, Vec3d pos) {
        MinecraftServer server = world.getServer();
        ServerCommandSource source = server.getCommandSource()
                .withWorld(world)
                .withPosition(pos)
                .withSilent();
        // The function command returns its execution result. Do not consume the egg if the
        // built-in function failed (for example, if its datapack resources were not loaded).
        int result = server.getCommandManager().executeWithPrefix(source, "function hurma:egg_summon");
        return result > 0;
    }
}
