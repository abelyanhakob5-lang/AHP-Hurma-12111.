package net.dawson.adorablehamsterpets.entity.client;

import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.renderer.base.RenderPassInfo;
import com.geckolib.renderer.layer.GeoRenderLayer;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.Identifier;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;

/**
 * GeckoLib 5 render-state based redstone-fever eye overlay.
 *
 * Entity-only values are captured in addRenderData; submitRenderTask does not
 * access the live HamsterEntity, matching GeckoLib 5's deferred render pipeline.
 */
public final class RedstoneFeverEyesRenderLayer
        extends GeoRenderLayer<HamsterEntity, Void, LivingEntityRenderState> {

    private static final Identifier FEVER_EYES_TEXTURE = Identifier.of(
            "adorablehamsterpets",
            "textures/entity/hamster/appearance/conditions/redstone_fever/eyes.png");

    private static final DataTicket<Boolean> HAS_REDSTONE_FEVER =
            DataTicket.create("adorablehamsterpets_has_redstone_fever", Boolean.class);

    public RedstoneFeverEyesRenderLayer(HamsterRenderer renderer) {
        super(renderer);
    }

    @Override
    public void addRenderData(HamsterEntity animatable, Void relatedObject,
                              LivingEntityRenderState renderState, float partialTick) {
        renderState.addGeckolibData(HAS_REDSTONE_FEVER,
                animatable.hasRedstoneFever() && !animatable.isInvisible());
    }

    @Override
    public void submitRenderTask(RenderPassInfo<LivingEntityRenderState> renderPassInfo,
                                 OrderedRenderCommandQueue renderTasks) {
        if (!renderPassInfo.getOrDefaultGeckolibData(HAS_REDSTONE_FEVER, false)) {
            return;
        }

        RenderLayer eyesRenderType = RenderLayer.getEyes(FEVER_EYES_TEXTURE);
        MatrixStack matrices = renderPassInfo.poseStack();

        renderTasks.submitCustomGeometry(matrices, eyesRenderType, (pose, vertexConsumer) -> {
            matrices.push();
            matrices.peek().set(pose);
            renderPassInfo.renderPosed(() -> renderPassInfo.model().render(
                    renderPassInfo,
                    vertexConsumer,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE,
                    renderPassInfo.packedOverlay(),
                    renderPassInfo.renderColor()));
            matrices.pop();
        });
    }
}
