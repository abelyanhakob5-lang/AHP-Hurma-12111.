package net.dawson.adorablehamsterpets.block.client;

import net.dawson.adorablehamsterpets.component.ModDataComponentTypes;
import net.dawson.adorablehamsterpets.item.client.HamsterBedItemModel;
import net.dawson.adorablehamsterpets.item.custom.HamsterBedItem;
import net.minecraft.item.ItemStack;
import com.geckolib.renderer.GeoItemRenderer;

public class HamsterBedItemRenderer extends GeoItemRenderer<HamsterBedItem> {
    public HamsterBedItemRenderer() {
        super(new HamsterBedItemModel());
    }

}