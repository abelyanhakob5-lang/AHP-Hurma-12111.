package net.dawson.adorablehamsterpets.hurma;

import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

/** Spawn egg for "Дядя Гриша" (the Hurma trader). Spawns the same trader as the /trigger hurma path. */
public class HurmaTraderEggItem extends Item {

    public HurmaTraderEggItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (!(world instanceof ServerWorld serverWorld)) {
            return ActionResult.SUCCESS;
        }
        BlockPos pos = context.getBlockPos().offset(context.getSide());
        if (HurmaTrader.spawnEgg(serverWorld, Vec3d.ofBottomCenter(pos))) {
            if (context.getPlayer() != null) {
                context.getStack().decrementUnlessCreative(1, context.getPlayer());
            }
            return ActionResult.CONSUME;
        }
        return ActionResult.FAIL;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.adorablehamsterpets.hurma_trader_egg").formatted(Formatting.GOLD));
        super.appendTooltip(stack, context, tooltip, type);
    }
}
