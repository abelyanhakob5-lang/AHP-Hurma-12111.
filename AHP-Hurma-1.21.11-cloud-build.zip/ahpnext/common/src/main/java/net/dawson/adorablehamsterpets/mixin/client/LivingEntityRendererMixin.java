package net.dawson.adorablehamsterpets.mixin.client;

import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Prevent vanilla's entity visibility pass from scheduling a second render for
 * living passengers of a hamster. The hamster attachment layer submits those
 * passengers explicitly at the animated body_child bone using the 1.21.11
 * render-state API.
 */
@Mixin(EntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(
            method = "shouldRender(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/Frustum;DDD)Z",
            at = @At("HEAD"),
            cancellable = true)
    private void adorablehamsterpets$cancelDuplicatePassengerRender(
            Entity entity, Frustum frustum, double x, double y, double z,
            CallbackInfoReturnable<Boolean> cir) {
        if (entity.getVehicle() instanceof HamsterEntity) {
            cir.setReturnValue(false);
        }
    }
}
