package net.dawson.adorablehamsterpets.block.client;

import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.renderer.GeoBlockRenderer;
import com.geckolib.renderer.base.RenderPassInfo;
import net.dawson.adorablehamsterpets.block.custom.HamsterBedBlock;
import net.dawson.adorablehamsterpets.block.entity.HamsterBedBlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.render.block.entity.state.BlockEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Direction;

/**
 * GeckoLib 5 render-state renderer for the hamster bed.
 */
public class HamsterBedRenderer extends GeoBlockRenderer<HamsterBedBlockEntity, BlockEntityRenderState> {
    private static final DataTicket<Boolean> UPSIDE_DOWN =
            DataTicket.create("adorablehamsterpets_bed_upside_down", Boolean.class);

    public HamsterBedRenderer(BlockEntityRendererFactory.Context context) {
        super(context, new HamsterBedModel());
    }

    @Override
    protected Direction getBlockStateDirection(HamsterBedBlockEntity block) {
        BlockState state = block.getCachedState();
        return state.contains(HamsterBedBlock.ORIENTATION)
                ? state.get(HamsterBedBlock.ORIENTATION)
                : super.getBlockStateDirection(block);
    }

    @Override
    public void captureDefaultRenderState(HamsterBedBlockEntity blockEntity, Void relatedObject,
                                          BlockEntityRenderState renderState, float partialTick) {
        super.captureDefaultRenderState(blockEntity, relatedObject, renderState, partialTick);
        renderState.addGeckolibData(UPSIDE_DOWN,
                blockEntity.getCachedState().get(HamsterBedBlock.UPSIDE_DOWN));
    }

    @Override
    public void adjustRenderPose(RenderPassInfo<BlockEntityRenderState> renderPassInfo) {
        super.adjustRenderPose(renderPassInfo);
        if (renderPassInfo.getOrDefaultGeckolibData(UPSIDE_DOWN, false)) {
            MatrixStack poseStack = renderPassInfo.poseStack();
            poseStack.translate(0.5, 0.5, 0.5);
            poseStack.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(180));
            poseStack.translate(-0.5, -0.5, -0.5);
        }
    }
}
