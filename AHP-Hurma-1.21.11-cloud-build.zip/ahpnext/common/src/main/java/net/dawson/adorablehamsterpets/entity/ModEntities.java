package net.dawson.adorablehamsterpets.entity;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.entity.custom.HamsterBlockHiderEntity;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.dawson.adorablehamsterpets.entity.custom.HamsterProjectileEntity;
import net.dawson.adorablehamsterpets.entity.custom.HamsterTreeSearcherEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.RegistryKeys;

public class ModEntities {

    // --- 1. DeferredRegister for EntityTypes ---
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(AdorableHamsterPets.MOD_ID, RegistryKeys.ENTITY_TYPE);

    // --- 2. EntityType Registration as a RegistrySupplier ---
    public static final RegistrySupplier<EntityType<HamsterEntity>> HAMSTER = ENTITY_TYPES.register("hamster", () ->
            EntityType.Builder.create(HamsterEntity::new, SpawnGroup.CREATURE)
                    .dimensions(0.425F, 0.425F).build("hamster"));

    public static final RegistrySupplier<EntityType<HamsterTreeSearcherEntity>> HAMSTER_TREE_SEARCHER = ENTITY_TYPES.register("hamster_tree_searcher", () ->
            EntityType.Builder.<HamsterTreeSearcherEntity>create(HamsterTreeSearcherEntity::new, SpawnGroup.MISC)
                    .dimensions(0.01F, 0.01F) // Tiny, invisible
                    .build("hamster_tree_searcher"));

    public static final RegistrySupplier<EntityType<HamsterBlockHiderEntity>> HAMSTER_BLOCK_HIDER = ENTITY_TYPES.register("hamster_block_hider", () ->
            EntityType.Builder.<HamsterBlockHiderEntity>create(HamsterBlockHiderEntity::new, SpawnGroup.MISC)
                    .dimensions(0.01F, 0.01F) // Tiny, invisible
                    .build("hamster_block_hider"));

    public static final RegistrySupplier<EntityType<HamsterProjectileEntity>> HAMSTER_PROJECTILE = ENTITY_TYPES.register("hamster_projectile", () ->
            EntityType.Builder.<HamsterProjectileEntity>create(HamsterProjectileEntity::new, SpawnGroup.MISC)
                    .dimensions(0.425F, 0.425F) // Match hamster size
                    .build("hamster_projectile"));

    // --- 3. Main Registration Call ---
    public static void register() {
        ENTITY_TYPES.register();
    }
}