package net.dawson.adorablehamsterpets.entity.client;

import java.lang.Math;

import dev.architectury.networking.NetworkManager;
import net.dawson.adorablehamsterpets.AdorableHamsterPetsClient;
import net.dawson.adorablehamsterpets.config.Configs;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.dawson.adorablehamsterpets.networking.payload.HamsterAnimationSoundPayload;
import net.dawson.adorablehamsterpets.sound.ModSounds;
import net.dawson.adorablehamsterpets.util.HamsterRenderUtil;
import net.dawson.adorablehamsterpets.util.HamsterTextureUtil;
import net.dawson.adorablehamsterpets.util.RedstoneFeverUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.random.Random;
import org.joml.*;
import com.geckolib.animatable.instance.AnimatableInstanceCache;
import com.geckolib.animation.AnimatableManager;
import com.geckolib.cache.model.BakedGeoModel;
import com.geckolib.renderer.GeoEntityRenderer;
import com.geckolib.renderer.base.BoneSnapshots;
import com.geckolib.renderer.base.RenderPassInfo;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import com.geckolib.constant.dataticket.DataTicket;

public class HamsterRenderer extends GeoEntityRenderer<HamsterEntity, LivingEntityRenderState> {

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Constants and Static Utilities
     * ────────────────────────────────────────────────────────────────────────────*/

    private static final String SEAT_BONE = "body_child";

    private static final DataTicket<Identifier> HAMSTER_TEXTURE =
            DataTicket.create("adorablehamsterpets_hamster_texture", Identifier.class);
    static final DataTicket<Float> RENDER_PARTIAL_TICK =
            DataTicket.create("adorablehamsterpets_render_partial_tick", Float.class);

    private static final Identifier FALLBACK_TEXTURE =
            Identifier.of("adorablehamsterpets", "textures/entity/hamster/fur_base_pattern/fur_pattern.png");

    // Suppresses nameplate inside inventory GUI
    public static final ThreadLocal<Boolean> IS_RENDERING_IN_GUI = ThreadLocal.withInitial(() -> false);

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Instance Fields
     * ────────────────────────────────────────────────────────────────────────────*/

    private final float adultShadowRadius = 0.2F;

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Constructors
     * ────────────────────────────────────────────────────────────────────────────*/

    public HamsterRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new HamsterModel());
        this.withRenderLayer(new RedstoneFeverEyesRenderLayer(this));
        this.withRenderLayer(new HamsterAttachmentRenderLayer(this));
        this.shadowRadius = this.adultShadowRadius;
    }

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Overrides
     * ────────────────────────────────────────────────────────────────────────────*/

    @Override
    public void addRenderData(HamsterEntity animatable, Void relatedObject,
                              LivingEntityRenderState renderState, float partialTick) {
        super.addRenderData(animatable, relatedObject, renderState, partialTick);
        // Resolve the per-hamster texture while the live entity is available.
        // GeckoLib 5 render submission uses the immutable render-state snapshot.
        renderState.addGeckolibData(HAMSTER_TEXTURE, HamsterTextureUtil.getHamsterTexture(animatable));
        renderState.addGeckolibData(RENDER_PARTIAL_TICK, partialTick);
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState renderState) {
        return renderState.getOrDefaultGeckolibData(HAMSTER_TEXTURE, FALLBACK_TEXTURE);
    }

    @Override
    public void adjustModelBonesForRender(RenderPassInfo<LivingEntityRenderState> renderPassInfo,
                                          BoneSnapshots snapshots) {
        HamsterEntity entity = renderPassInfo.renderState().getGeckolibData(HamsterModel.HAMSTER_ENTITY);
        if (entity != null) {
            ((HamsterModel) this.model).adjustModelBones(entity, snapshots);
        }
    }

    @Override
    public void preRenderPass(RenderPassInfo<LivingEntityRenderState> renderPassInfo,
                              OrderedRenderCommandQueue renderTasks) {
        super.preRenderPass(renderPassInfo, renderTasks);
        applyHamsterRenderTransforms(renderPassInfo);
        // Keep bone matrix tracking enabled for GeckoLib 5's deferred model submission.
        renderPassInfo.model().getBone("left_foot").ifPresent(bone -> bone.setTrackingMatrices(true));
        renderPassInfo.model().getBone("nose").ifPresent(bone -> bone.setTrackingMatrices(true));
        renderPassInfo.model().getBone(SEAT_BONE).ifPresent(bone -> bone.setTrackingMatrices(true));
    }

    /**
     * GeckoLib 5 equivalent of the transform work previously performed in render(entity,...).
     * Render-state data is read before the model is submitted to the deferred render queue.
     */
    private void applyHamsterRenderTransforms(RenderPassInfo<LivingEntityRenderState> info) {
        HamsterEntity entity = info.renderState().getGeckolibData(HamsterModel.HAMSTER_ENTITY);
        if (entity == null) {
            return;
        }

        MatrixStack poseStack = info.poseStack();
        float partialTick = info.renderState().getOrDefaultGeckolibData(RENDER_PARTIAL_TICK, 1.0f);
        AdorableHamsterPetsClient.onHamsterRendered(entity.getId());
        // Shadow size belongs to this entity's render-state snapshot. Mutating the
        // shared renderer instance here leaks baby/adult shadow sizes across hamsters.
        info.renderState().shadowRadius = entity.isBaby()
                ? this.adultShadowRadius * 0.5f
                : this.adultShadowRadius;

        if (entity.hasRedstoneFever() && !entity.isRedstoneFeverBurstActive() && !IS_RENDERING_IN_GUI.get()) {
            double baseAmplitude = 0.000D;
            double spikeAmplitude = 0.015D;
            double renderTime = entity.getWorld().getTime() + partialTick;
            double severity = entity.getSynchronizedRedstoneFeverSeverity();
            double spike = RedstoneFeverUtil.getTremorSpike(renderTime, entity.getUuid()) * spikeAmplitude;
            double finalAmplitude = (baseAmplitude + spike) * severity;
            double amplitudePulse = (baseAmplitude + spike) / (baseAmplitude + spikeAmplitude);
            double entityPhase = entity.getUuid().hashCode() * 0.61803398875D;
            poseStack.translate(Math.sin(renderTime * 4.73D + entityPhase) * finalAmplitude, 0.0D,
                    Math.cos(renderTime * 4.39D + entityPhase) * finalAmplitude);
            double roll = Math.toRadians(2.5D) * amplitudePulse * severity
                    * Math.sin(renderTime * 4.17D + entityPhase);
            poseStack.multiply(RotationAxis.POSITIVE_Z.rotation((float) roll));
        }

        if (IS_RENDERING_IN_GUI.get() || entity.isShoulderPet() || entity.isProjectileDummy) {
            entity.renderedGroundYOffset = 0.0F;
        } else {
            float targetYOffset = HamsterRenderUtil.getGroundSurfaceOffset(entity);
            entity.renderedGroundYOffset += (targetYOffset - entity.renderedGroundYOffset) * 0.15F;
            poseStack.translate(0.0, entity.renderedGroundYOffset, 0.0);
        }

        double currentTick = entity.age + partialTick;
        AnimatableInstanceCache cache = entity.getAnimatableInstanceCache();
        if (cache != null) {
            AnimatableManager<?> manager = cache.getManagerForId(entity.getId());
            if (manager != null && currentTick == entity.lastRenderTime) {
                manager.updatedAt(currentTick - 0.0000001);
            }
        }
        entity.lastRenderTime = currentTick;
    }

    @Override
    public boolean hasLabel(HamsterEntity entity) {
        if (IS_RENDERING_IN_GUI.get()) {
            return false;
        }
        return super.hasLabel(entity);
    }

    // GeckoLib 5 uses render-state extraction and deferred render submission.
    // Transform logic previously in render(entity, ...) now lives in preRenderPass().
    @Override
    public void postRenderPass(RenderPassInfo<LivingEntityRenderState> renderPassInfo,
                               OrderedRenderCommandQueue renderTasks) {
        super.postRenderPass(renderPassInfo, renderTasks);

        // Keyframe side effects are handled after GeckoLib has submitted the model pass,
        // when the animated bone matrices are available. Attached riders/items still
        // need a dedicated per-bone deferred-render task; the old immediate renderFinal
        // callback is not part of GeckoLib 5.
        HamsterEntity hamster = renderPassInfo.renderState().getGeckolibData(HamsterModel.HAMSTER_ENTITY);
        if (hamster == null) {
            return;
        }

        BakedGeoModel model = renderPassInfo.model();
        // Shoulder rendering is cosmetic and must not emit world-interactive effects.
        if (!hamster.isShoulderPet()) {
            if (hamster.particleEffectId != null) {
                handleParticleKeyframes(hamster, model);
            }
            if (hamster.soundEffectId != null) {
                handleSoundKeyframes(hamster);
            }
        }
    }

    /* ──────────────────────────────────────────────────────────────────────────────
     *        Private Helpers
     * ────────────────────────────────────────────────────────────────────────────*/

    private void handleParticleKeyframes(HamsterEntity animatable, BakedGeoModel model) {
        Random random = animatable.getRandom();
        switch (animatable.particleEffectId) {
            case "attack_poof":
                model.getBone("left_foot").ifPresent(bone -> {
                    Vector3d pos = bone.getWorldPosition();
                    for (int i = 0; i < 8; ++i) {
                        double d = random.nextGaussian() * 0.1;
                        double e = random.nextGaussian() * 0.2;
                        double f = random.nextGaussian() * 0.1;
                        animatable.getWorld().addParticle(ParticleTypes.WHITE_SMOKE,
                                pos.x + d, pos.y + e, pos.z + f,
                                random.nextGaussian() * 0.05,
                                random.nextGaussian() * 0.05,
                                random.nextGaussian() * 0.05);
                    }
                });
                break;
            case "seeking_dust":
                model.getBone("nose").ifPresent(bone -> {
                    Vector3d pos = bone.getWorldPosition();
                    BlockPos blockBelow = BlockPos.ofFloored(pos.x, pos.y - 0.1, pos.z).down();
                    BlockState state = animatable.getWorld().getBlockState(blockBelow);
                    if (state.isAir()) state = Blocks.DIRT.getDefaultState();
                    for (int i = 0; i < 12; ++i) {
                        double d = random.nextGaussian() * 0.2;
                        double e = random.nextGaussian() * 0.03;
                        double f = random.nextGaussian() * 0.2;
                        animatable.getWorld().addParticle(new BlockStateParticleEffect(ParticleTypes.FALLING_DUST, state),
                                pos.x + d, pos.y + e, pos.z + f,
                                0.0, 0.0, 0.0);
                    }
                });
                break;
            case "hamster_spit_particles":
                // Spawn items and spit them out
                model.getBone("nose").ifPresent(bone -> {
                    Vector3d pos = bone.getWorldPosition();
                    // 1. Item Particles (if holding item)
                    ItemStack mouthStack = animatable.getMouthItemStack();
                    if (!mouthStack.isEmpty()) {
                        for (int i = 0; i < 5; i++) {
                            animatable.getWorld().addParticle(
                                    new ItemStackParticleEffect(ParticleTypes.ITEM, mouthStack),
                                    pos.x, pos.y, pos.z,
                                    (random.nextDouble() - 0.5) * 0.3,
                                    random.nextDouble() * 0.2,
                                    (random.nextDouble() - 0.5) * 0.3
                            );
                        }
                    }
                    // 2. Llama Spit Particles
                    for (int i = 0; i < 8; i++) {
                        animatable.getWorld().addParticle(
                                ParticleTypes.SPIT,
                                pos.x, pos.y, pos.z,
                                (random.nextDouble() - 0.5) * 0.1,
                                random.nextDouble() * 0.1,
                                (random.nextDouble() - 0.5) * 0.1
                        );
                    }
                });
                break;
        }
        animatable.particleEffectId = null;
    }

    private void handleSoundKeyframes(HamsterEntity animatable) {
        MinecraftClient client = MinecraftClient.getInstance();
        switch (animatable.soundEffectId) {
            case "dynamic_item_sound":
                ItemStack mouthStack = animatable.getMouthItemStack();
                if (!mouthStack.isEmpty()) {
                    SoundEvent dynamicSound = ModSounds.getDynamicItemSound(mouthStack);
                    float baseVol = ModSounds.getDynamicSoundVolume(dynamicSound);

                    client.getSoundManager().play(new PositionedSoundInstance(
                            dynamicSound, SoundCategory.NEUTRAL, baseVol * 0.6f, 1.0f + (animatable.getRandom().nextFloat() - 0.5f) * 0.2f,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_scratch_sound":
                SoundEvent scratchSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_SCRATCH_SOUNDS, animatable.getRandom());
                if (scratchSound != null) {
                    client.getSoundManager().play(new PositionedSoundInstance(
                            scratchSound, SoundCategory.NEUTRAL, 0.2f, 0.8f,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_roll_back_sound":
                SoundEvent rollBackSound = Configs.AHP_MAIN.enableRollingSlideWhistle
                        ? ModSounds.HAMSTER_ROLL_BACK.get()
                        : ModSounds.HAMSTER_ROLL_BACK_NO_SLIDE_WHISTLE.get();

                client.getSoundManager().play(new PositionedSoundInstance(
                        rollBackSound, SoundCategory.NEUTRAL, 0.3f, 1.4f,
                        animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                ));
                break;
            case "hamster_roll_forward_sound":
                client.getSoundManager().play(new PositionedSoundInstance(
                        ModSounds.HAMSTER_ROLL_FORWARD.get(), SoundCategory.NEUTRAL, 0.2f, 1.4f,
                        animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                ));
                break;
            case "hamster_step_sound":
                BlockPos pos = animatable.getBlockPos();
                BlockState blockState = animatable.getWorld().getBlockState(pos.down());
                if (blockState.isAir()) blockState = animatable.getWorld().getBlockState(pos.down(2));
                if (!blockState.isAir()) {
                    BlockSoundGroup group = blockState.getSoundGroup();
                    float volume = blockState.isOf(Blocks.GRAVEL) ? (0.10F * 0.60F) : 0.10F;
                    client.getSoundManager().play(new PositionedSoundInstance(
                            group.getStepSound(), SoundCategory.NEUTRAL, volume,
                            group.getPitch() * 1.5F, animatable.getRandom(),
                            animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_bounce_sound":
                if (animatable.isDancing()) break; // Mute bounce sound when dancing to music disc
                SoundEvent bounceSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_BOUNCE_SOUNDS, animatable.getRandom());
                if (bounceSound != null) {
                    float basePitch = animatable.getSoundPitch();
                    float randomPitchAddition = animatable.getRandom().nextFloat() * 0.2f;
                    float finalPitch = (basePitch * 1.2f) + randomPitchAddition;
                    client.getSoundManager().play(new PositionedSoundInstance(
                            bounceSound, SoundCategory.NEUTRAL, 0.6f, finalPitch,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_thump_sound":
                float thumpPitch = 1.0F + animatable.getRandom().nextFloat() * 0.4F;
                client.getSoundManager().play(new PositionedSoundInstance(
                        ModSounds.HAMSTER_THUMP.get(), SoundCategory.NEUTRAL, 0.3f, thumpPitch,
                        animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                ));

                // Broadcast via server if >16.0 blocks from player to bypass vanilla distance attenuation
                if (client.player != null) {
                    if (animatable.squaredDistanceTo(client.player) > 16.0 * 16.0) {
                        NetworkManager.sendToServer(
                                new HamsterAnimationSoundPayload(animatable.getId(), "hamster_thump_sound")
                        );
                    }
                }
                break;
            case "hamster_spit_sound":
                client.getSoundManager().play(new PositionedSoundInstance(
                        SoundEvents.ENTITY_LLAMA_SPIT, SoundCategory.NEUTRAL, 0.4f, 2.0f,
                        animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                ));
                break;
            case "hamster_sniff_sound":
                SoundEvent sniffSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_DIAMOND_SNIFF_SOUNDS, animatable.getRandom());
                if (sniffSound != null) {
                    client.getSoundManager().play(new PositionedSoundInstance(
                            sniffSound, SoundCategory.NEUTRAL, 1.0f, animatable.getSoundPitch(),
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_head_shake_fast_sound":
                client.getSoundManager().play(new PositionedSoundInstance(
                        ModSounds.HAMSTER_HEAD_SHAKE_FAST.get(), SoundCategory.NEUTRAL, 0.35f, 1.0f + (animatable.getRandom().nextFloat() - 0.5f) * 0.2f,
                        animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                ));
                break;
            case "hamster_swish_sound":
                client.getSoundManager().play(new PositionedSoundInstance(
                        ModSounds.HAMSTER_SWISH.get(), SoundCategory.NEUTRAL, 0.1f, 1.0f + (animatable.getRandom().nextFloat() * 0.5f),
                        animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                ));
                break;
            case "hamster_water_swish_sound":
                SoundEvent waterSwishSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_WATER_SWISH_SOUNDS, animatable.getRandom());
                if (waterSwishSound != null) {
                    client.getSoundManager().play(new PositionedSoundInstance(
                            waterSwishSound, SoundCategory.NEUTRAL, 0.25f, 1.0f,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_affection_sound":
                SoundEvent affectionSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_AFFECTION_SOUNDS, animatable.getRandom());
                if (affectionSound != null) {
                    client.getSoundManager().play(new PositionedSoundInstance(
                            affectionSound, SoundCategory.NEUTRAL, 1.0f, 1.0f,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_celebrate_sound":
                SoundEvent celebrateSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_CELEBRATE_SOUNDS, animatable.getRandom());
                if (celebrateSound != null) {
                    client.getSoundManager().play(new PositionedSoundInstance(
                            celebrateSound, SoundCategory.NEUTRAL, 1.0f, 1.0f,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
            case "hamster_sneeze_sound":
                SoundEvent sneezeSound = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_SNEEZE_SOUNDS, animatable.getRandom());
                if (sneezeSound != null) {
                    client.getSoundManager().play(new PositionedSoundInstance(
                            sneezeSound, SoundCategory.NEUTRAL, 0.6f, 1.0f,
                            animatable.getRandom(), animatable.getX(), animatable.getY(), animatable.getZ()
                    ));
                }
                break;
        }
        animatable.soundEffectId = null;
    }
}
