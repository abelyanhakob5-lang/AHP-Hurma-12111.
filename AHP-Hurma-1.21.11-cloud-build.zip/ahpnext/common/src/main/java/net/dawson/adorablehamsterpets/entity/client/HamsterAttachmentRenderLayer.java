package net.dawson.adorablehamsterpets.entity.client;

import java.util.function.BiConsumer;

import com.geckolib.cache.model.GeoBone;
import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.renderer.base.PerBoneRender;
import com.geckolib.renderer.base.RenderPassInfo;
import com.geckolib.renderer.layer.GeoRenderLayer;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.dawson.adorablehamsterpets.util.HamsterMouthItemOffsets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;
import net.dawson.adorablehamsterpets.util.HamsterRidingUtil;

/**
 * Deferred attachments for the hamster model.
 *
 * The held item is submitted as a per-bone render task so it follows the animated
 * nose bone and uses Minecraft 1.21.11's ordered render-command queue.
 */
public final class HamsterAttachmentRenderLayer
        extends GeoRenderLayer<HamsterEntity, Void, LivingEntityRenderState> {

    private static final DataTicket<ItemStack> MOUTH_ITEM_STACK =
            DataTicket.create("adorablehamsterpets_mouth_item_stack", ItemStack.class);
    private static final DataTicket<Entity[]> PASSENGERS =
            DataTicket.create("adorablehamsterpets_passenger_snapshot", Entity[].class);

    public HamsterAttachmentRenderLayer(HamsterRenderer renderer) {
        super(renderer);
    }

    @Override
    public void addRenderData(HamsterEntity animatable, Void relatedObject,
                              LivingEntityRenderState renderState, float partialTick) {
        super.addRenderData(animatable, relatedObject, renderState, partialTick);

        ItemStack stack = animatable.getMouthItemStack();
        // Snapshot the stack for the deferred pass instead of reading a mutable
        // live stack after submission.
        renderState.addGeckolibData(MOUTH_ITEM_STACK, stack.isEmpty() ? ItemStack.EMPTY : stack.copy());
        renderState.addGeckolibData(PASSENGERS, animatable.getPassengerList().toArray(Entity[]::new));
    }

    @Override
    public void addPerBoneRender(
            RenderPassInfo<LivingEntityRenderState> renderPassInfo,
            BiConsumer<GeoBone, PerBoneRender<LivingEntityRenderState>> consumer) {

        ItemStack stack = renderPassInfo.getGeckolibData(MOUTH_ITEM_STACK);
        if (stack != null && !stack.isEmpty()) {
            renderPassInfo.model().getBone("nose").ifPresent(nose ->
                    consumer.accept(nose, (passInfo, ignoredBone, renderTasks) -> {
                        HamsterEntity hamster = passInfo.getGeckolibData(HamsterModel.HAMSTER_ENTITY);
                        ItemStack mouthStack = passInfo.getGeckolibData(MOUTH_ITEM_STACK);
                        if (hamster == null || mouthStack == null || mouthStack.isEmpty()) {
                            return;
                        }

                        MatrixStack matrices = passInfo.poseStack();
                        matrices.push();
                        try {
                            // GeckoLib has already posed the stack at the nose bone.
                            HamsterMouthItemOffsets.applyMouthItemTransforms(matrices);
                            MinecraftClient.getInstance().getHeldItemRenderer().renderItem(
                                    hamster, mouthStack, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND,
                                    matrices, renderTasks, passInfo.packedLight());
                        } finally {
                            matrices.pop();
                        }
                    }));
        }

        Entity[] passengers = renderPassInfo.getGeckolibData(PASSENGERS);
        if (passengers == null || passengers.length == 0) {
            return;
        }

        renderPassInfo.model().getBone("body_child").ifPresent(body ->
                consumer.accept(body, (passInfo, bone, renderTasks) -> {
                    HamsterEntity hamster = passInfo.getGeckolibData(HamsterModel.HAMSTER_ENTITY);
                    Entity[] riderSnapshot = passInfo.getGeckolibData(PASSENGERS);
                    if (hamster == null || riderSnapshot == null || hamster.isShoulderPet()) {
                        return;
                    }

                    MinecraftClient client = MinecraftClient.getInstance();
                    EntityRenderManager dispatcher = client.getEntityRenderDispatcher();
                    float partialTick = passInfo.getOrDefaultGeckolibData(
                            HamsterRenderer.RENDER_PARTIAL_TICK, 1.0f);

                    for (Entity passenger : riderSnapshot) {
                        if (!(passenger instanceof LivingEntity living) || passenger.isRemoved()) {
                            continue;
                        }
                        if (passenger == client.player && client.options.getPerspective().isFirstPerson()) {
                            continue;
                        }

                        MatrixStack matrices = passInfo.poseStack();
                        matrices.push();
                        try {
                            // The per-bone queue already positions the stack at body_child.
                            // Cancel bone and mount scaling so the rider keeps their own size.
                            Vector3f boneScale = bone.getModelSpaceMatrix().getScale(new Vector3f());
                            if (Math.abs(boneScale.x) > 1.0e-4f
                                    && Math.abs(boneScale.y) > 1.0e-4f
                                    && Math.abs(boneScale.z) > 1.0e-4f) {
                                matrices.scale(1.0f / boneScale.x, 1.0f / boneScale.y, 1.0f / boneScale.z);
                            }
                            float mountScale = hamster.getScale();
                            if (Math.abs(mountScale) > 1.0e-4f && mountScale != 1.0f) {
                                float inverseMountScale = 1.0f / mountScale;
                                matrices.scale(inverseMountScale, inverseMountScale, inverseMountScale);
                            }

                            Vec3d seat = HamsterRidingUtil.HamsterSeatOffsets
                                    .visualSeatOffset(living, hamster.getScale());
                            matrices.translate(seat.x, seat.y, seat.z);

                            // EntityRenderer.render(state, ...) applies the passenger's interpolated
                            // body/head rotations itself. Applying passenger yaw here as well would
                            // rotate the rider twice relative to the animated seat bone.

                            // Submit using the 1.21.11 render-state path, not the removed immediate renderer API.
                            EntityRenderer renderer = dispatcher.getRenderer(passenger);
                            EntityRenderState passengerState =
                                    renderer.getAndUpdateRenderState(passenger, partialTick);
                            passengerState.shadowRadius = 0;

                            // Invoke the render-state renderer directly. This bypasses the
                            // dispatcher's shouldRender culling hook, which suppresses the
                            // duplicate vanilla pass for mounted passengers.
                            renderer.render(passengerState, matrices, renderTasks, passInfo.cameraState());
                        } finally {
                            matrices.pop();
                        }
                    }
                }));
    }

}
