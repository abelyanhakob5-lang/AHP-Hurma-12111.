package net.dawson.adorablehamsterpets.item.client;

import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.item.custom.HamsterBedItem;
import net.minecraft.util.Identifier;
import com.geckolib.model.GeoModel;
import com.geckolib.renderer.base.GeoRenderState;
import com.geckolib.constant.dataticket.DataTicket;

@SuppressWarnings({"removal"})
public final class HamsterBedItemModel extends GeoModel<HamsterBedItem> {

    public static final DataTicket<Identifier> BED_TEXTURE =
            DataTicket.create("adorablehamsterpets_bed_item_texture", Identifier.class);

    @Override
    public void addAdditionalStateData(HamsterBedItem animatable, Object relatedObject, GeoRenderState renderState) {
        var variant = animatable.getVariant();
        renderState.addGeckolibData(BED_TEXTURE, Identifier.of(AdorableHamsterPets.MOD_ID,
                "textures/block/hamster_bed_" + variant.asString() + ".png"));
    }

    @Override
    public Identifier getModelResource(GeoRenderState renderState) {
        return Identifier.of(AdorableHamsterPets.MOD_ID, "hamster_bed");
    }

    @Override
    public Identifier getTextureResource(GeoRenderState renderState) {
        return renderState.getOrDefaultGeckolibData(BED_TEXTURE,
                Identifier.of(AdorableHamsterPets.MOD_ID, "textures/block/hamster_bed_oak.png"));
    }

    @Override
    public Identifier getAnimationResource(HamsterBedItem animatable) {
        return Identifier.of(AdorableHamsterPets.MOD_ID, "anim_hamster_bed");
    }

}
