package net.dawson.adorablehamsterpets.block;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.block.custom.*;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.block.enums.NoteBlockInstrument;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;

import java.util.function.Supplier;

public class ModBlocks {

    // --- 1. Create a DeferredRegister for Blocks ---
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(AdorableHamsterPets.MOD_ID, RegistryKeys.BLOCK);

    // --- 2. Change Block fields to RegistrySuppliers ---
    public static final RegistrySupplier<Block> GREEN_BEANS_CROP = registerBlock("green_beans_crop",
            () -> new GreenBeansCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT).sounds(BlockSoundGroup.CROP).nonOpaque().noCollision()));

    public static final RegistrySupplier<Block> CUCUMBER_CROP = registerBlock("cucumber_crop",
            () -> new CucumberCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT).sounds(BlockSoundGroup.CROP).nonOpaque().noCollision()));

    public static final RegistrySupplier<Block> WILD_GREEN_BEAN_BUSH = registerBlock("wild_green_bean_bush",
            () -> new WildGreenBeanBushBlock(AbstractBlock.Settings.copy(Blocks.SWEET_BERRY_BUSH)
                    .nonOpaque()
                    .noCollision()
                    .ticksRandomly()
                    .sounds(BlockSoundGroup.SWEET_BERRY_BUSH)));

    public static final RegistrySupplier<Block> WILD_CUCUMBER_BUSH = registerBlock("wild_cucumber_bush",
            () -> new WildCucumberBushBlock(AbstractBlock.Settings.copy(Blocks.SWEET_BERRY_BUSH)
                    .nonOpaque()
                    .noCollision()
                    .ticksRandomly()
                    .sounds(BlockSoundGroup.SWEET_BERRY_BUSH)));

    public static final RegistrySupplier<Block> SUNFLOWER_BLOCK = registerBlock("sunflower_block",
            () -> new SunflowerBlock(AbstractBlock.Settings.copy(Blocks.SUNFLOWER)
                    .nonOpaque()
                    .luminance(state -> state.get(SunflowerBlock.LIT) ? 15 : 0)));

    public static final RegistrySupplier<Block> HAMSTER_BED = registerBlock("hamster_bed",
            () -> new HamsterBedBlock(AbstractBlock.Settings.create().mapColor(MapColor.OAK_TAN).instrument(NoteBlockInstrument.BASS).strength(0.5F).sounds(BlockSoundGroup.WOOD).nonOpaque()));

    // --- Crates ---
    public static final RegistrySupplier<Block> ACORN_CRATE = registerBlock("acorn_crate",
            () -> new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).sounds(BlockSoundGroup.WOOD).strength(2.0F, 3.0F)));

    public static final RegistrySupplier<Block> CUCUMBER_CRATE = registerBlock("cucumber_crate",
            () -> new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).sounds(BlockSoundGroup.WOOD).strength(2.0F, 3.0F)));

    public static final RegistrySupplier<Block> GREEN_BEANS_CRATE = registerBlock("green_beans_crate",
            () -> new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).sounds(BlockSoundGroup.WOOD).strength(2.0F, 3.0F)));

    public static final RegistrySupplier<Block> HAMSTER_FOOD_MIX_CRATE = registerBlock("hamster_food_mix_crate",
            () -> new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).sounds(BlockSoundGroup.WOOD).strength(2.0F, 3.0F)));

    // --- 3. Private Helper Method for Block Registration ---
    private static RegistrySupplier<Block> registerBlock(String name, Supplier<Block> blockSupplier) {
        return BLOCKS.register(name, blockSupplier);
    }

    // --- 4. Main Registration Call ---
    public static void register() {
        BLOCKS.register();
    }
}