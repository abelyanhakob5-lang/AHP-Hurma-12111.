package net.dawson.adorablehamsterpets.hurma;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Hamster feed ("Корм для хомячка от Limangusa").
 *
 * <p>This is a real registered item. It deliberately has NO {@code FOOD} / consumable component,
 * so a player cannot eat it. Only a hamster can consume it, via {@link HamsterFeedUtil#handleFeed}.
 *
 * <p>All variants behave identically (enchanted-golden-apple effects, one item tames); the
 * variants differ by id, name and texture only.
 */
public class HamsterFeedItem extends Item {

    private final String variantKey;

    public HamsterFeedItem(Settings settings, String variantKey) {
        super(settings);
        this.variantKey = variantKey;
    }

    public String variantKey() {
        return variantKey;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("tooltip.adorablehamsterpets.hamster_feed.line1").formatted(Formatting.GOLD));
        tooltip.add(Text.translatable("tooltip.adorablehamsterpets.hamster_feed.line2").formatted(Formatting.GRAY));
        super.appendTooltip(stack, context, tooltip, type);
    }
}
