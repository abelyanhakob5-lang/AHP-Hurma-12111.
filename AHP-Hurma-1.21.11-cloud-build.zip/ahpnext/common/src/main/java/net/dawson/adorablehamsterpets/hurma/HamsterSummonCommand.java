package net.dawson.adorablehamsterpets.hurma;

import com.mojang.brigadier.CommandDispatcher;
import net.dawson.adorablehamsterpets.entity.ModEntities;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * {@code /hamster summon} — available to every player. There is NO {@code requires(...)} permission
 * check, so it works without operator rights and with cheats disabled. It only ever spawns one
 * hamster next to the caller; it never executes any other command.
 *
 * <p>Abuse limits: per-player cooldown and a cap on hamsters already near the player.
 */
public final class HamsterSummonCommand {

    private static final long COOLDOWN_TICKS = 20L * 30; // 30 s
    private static final int NEARBY_CAP = 8;
    private static final double NEARBY_RADIUS = 32.0;
    private static final Map<UUID, Long> LAST_USE = new ConcurrentHashMap<>();

    private HamsterSummonCommand() {}

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("hamster")
                .then(CommandManager.literal("summon")
                        .executes(ctx -> run(ctx.getSource()))));
    }

    private static int run(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.translatable("command.adorablehamsterpets.hamster.player_only"));
            return 0;
        }
        ServerWorld world = source.getWorld();
        long now = world.getTime();

        Long last = LAST_USE.get(player.getUuid());
        if (last != null && now - last < COOLDOWN_TICKS) {
            long left = (COOLDOWN_TICKS - (now - last) + 19) / 20;
            source.sendError(Text.translatable("command.adorablehamsterpets.hamster.cooldown", left));
            return 0;
        }

        Box box = player.getBoundingBox().expand(NEARBY_RADIUS);
        int nearby = world.getEntitiesByType(ModEntities.HAMSTER.get(), box, e -> true).size();
        if (nearby >= NEARBY_CAP) {
            source.sendError(Text.translatable("command.adorablehamsterpets.hamster.too_many"));
            return 0;
        }

        BlockPos spot = findSpot(world, player);
        if (spot == null) {
            source.sendError(Text.translatable("command.adorablehamsterpets.hamster.no_space"));
            return 0;
        }

        HamsterEntity hamster = ModEntities.HAMSTER.get().spawn(world, spot, SpawnReason.COMMAND);
        if (hamster == null) {
            source.sendError(Text.translatable("command.adorablehamsterpets.hamster.failed"));
            return 0;
        }
        hamster.setPersistent();
        LAST_USE.put(player.getUuid(), now);
        source.sendFeedback(() -> Text.translatable("command.adorablehamsterpets.hamster.summoned")
                .formatted(Formatting.GOLD), false);
        return 1;
    }

    /** A free 1x1x1 spot with solid, non-liquid ground, within ~3 blocks in front of / around the player. */
    private static BlockPos findSpot(ServerWorld world, ServerPlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0F);
        Vec3d flat = new Vec3d(look.x, 0, look.z);
        flat = flat.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 1) : flat.normalize();
        BlockPos base = player.getBlockPos();
        for (int dist : new int[]{2, 3, 1, 4}) {
            for (int dy : new int[]{0, 1, -1}) {
                BlockPos p = BlockPos.ofFloored(player.getX() + flat.x * dist, base.getY() + dy, player.getZ() + flat.z * dist);
                if (isFree(world, p)) return p;
            }
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos p = base.add(dx, 0, dz);
                if (isFree(world, p)) return p;
            }
        }
        return null;
    }

    private static boolean isFree(ServerWorld world, BlockPos p) {
        return world.getBlockState(p).getCollisionShape(world, p).isEmpty()
                && world.getFluidState(p).isEmpty()
                && world.getBlockState(p.up()).getCollisionShape(world, p.up()).isEmpty()
                && world.getBlockState(p.down()).isSolidBlock(world, p.down());
    }
}
