package net.dawson.adorablehamsterpets.hurma;

import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.dawson.adorablehamsterpets.sound.ModSounds;
import net.dawson.adorablehamsterpets.util.HamsterGeneticsAdvancementUtil;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

/**
 * Feeding / taming logic for {@link HamsterFeedItem}.
 *
 * <ul>
 *   <li>Untamed hamster + one feed item  -> tamed, owner = feeding player (100 %, exactly one item).</li>
 *   <li>Tamed hamster + feed item (owner only) -> eats it and gets the effects of an enchanted golden apple.</li>
 * </ul>
 * Effects are applied through the status-effect system; no vanilla item is substituted.
 */
public final class HamsterFeedUtil {

    // Enchanted golden apple (1.21.x): Regeneration II 20s, Resistance I 5min, Fire Resistance 5min, Absorption IV 2min.
    private static final int REGEN_TICKS = 20 * 20;
    private static final int RESISTANCE_TICKS = 5 * 60 * 20;
    private static final int FIRE_RES_TICKS = 5 * 60 * 20;
    private static final int ABSORPTION_TICKS = 2 * 60 * 20;

    private HamsterFeedUtil() {}

    public static ActionResult handleFeed(HamsterEntity hamster, PlayerEntity player, ItemStack stack, Hand hand) {
        if (!(stack.getItem() instanceof HamsterFeedItem)) return ActionResult.PASS;
        if (hamster.getWorld().isClient()) return ActionResult.SUCCESS;
        if (hamster.interactionCooldown > 0) return ActionResult.SUCCESS;

        boolean wasTamed = hamster.isTamed();
        if (wasTamed && !hamster.isOwner(player)) {
            return ActionResult.PASS; // only the owner feeds a tamed hamster
        }

        // Keep a copy of one item for particles/animation, then consume exactly one.
        ItemStack eaten = stack.copyWithCount(1);
        if (!player.getAbilities().creativeMode) {
            stack.decrement(1);
        }
        hamster.interactionCooldown = 10;

        if (!wasTamed) {
            tame(hamster, player);
        }

        applyAppleEffects(hamster);
        playEatFeedback(hamster, eaten);
        hamster.startFeedEating(eaten); // reuses the existing eating animation state
        return ActionResult.SUCCESS;
    }

    private static void tame(HamsterEntity hamster, PlayerEntity player) {
        hamster.setOwnerUuid(player.getUuid());
        hamster.setTamed(true, true);
        hamster.getNavigation().stop();
        hamster.setSitting(false, true);
        hamster.setSleeping(false);
        hamster.setTarget(null);
        if (hamster.isAiDisabled()) {
            hamster.setAiDisabled(false);
            hamster.setNoGravity(false);
            hamster.setInvulnerable(false);
        }
        hamster.setPersistent();
        hamster.getWorld().sendEntityStatus(hamster, (byte) 7); // hearts

        SoundEvent celebrate = ModSounds.getRandomSoundFrom(ModSounds.HAMSTER_CELEBRATE_SOUNDS, hamster.getRandom());
        hamster.getWorld().playSound(null, hamster.getBlockPos(), celebrate, SoundCategory.NEUTRAL, 0.7F, 1.0F);

        if (player instanceof ServerPlayerEntity serverPlayer) {
            Criteria.TAME_ANIMAL.trigger(serverPlayer, hamster);
            HamsterGeneticsAdvancementUtil.trackTamedHamster(serverPlayer, hamster);
        }
    }

    private static void applyAppleEffects(HamsterEntity hamster) {
        hamster.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, REGEN_TICKS, 1));
        hamster.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, RESISTANCE_TICKS, 0));
        hamster.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, FIRE_RES_TICKS, 0));
        hamster.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, ABSORPTION_TICKS, 3));
    }

    private static void playEatFeedback(HamsterEntity hamster, ItemStack eaten) {
        hamster.playSound(SoundEvents.ENTITY_GENERIC_EAT, 0.8F, 1.3F);
        if (hamster.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM, eaten),
                    hamster.getX(), hamster.getY() + hamster.getHeight() * 0.6, hamster.getZ(),
                    8, 0.1, 0.1, 0.1, 0.03);
        }
    }
}
