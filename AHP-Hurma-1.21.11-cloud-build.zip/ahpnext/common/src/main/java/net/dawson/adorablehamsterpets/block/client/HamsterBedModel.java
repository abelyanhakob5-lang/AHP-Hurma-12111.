package net.dawson.adorablehamsterpets.block.client;

import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.block.entity.HamsterBedBlockEntity;
import net.minecraft.util.Identifier;
import com.geckolib.model.GeoModel;
import com.geckolib.renderer.base.GeoRenderState;
import com.geckolib.constant.dataticket.DataTicket;

@SuppressWarnings({"removal"})
public class HamsterBedModel extends GeoModel<HamsterBedBlockEntity> {

    public static final DataTicket<Identifier> BED_TEXTURE =
            DataTicket.create("adorablehamsterpets_bed_texture", Identifier.class);

    @Override
    public void addAdditionalStateData(HamsterBedBlockEntity animatable, Object relatedObject, GeoRenderState renderState) {
        var state = animatable.getCachedState();
        var variant = state.contains(HamsterBedBlock.WOOD_VARIANT)
                ? state.get(HamsterBedBlock.WOOD_VARIANT).asString()
                : "oak";
        renderState.addGeckolibData(BED_TEXTURE, Identifier.of(AdorableHamsterPets.MOD_ID,
                "textures/block/hamster_bed_" + variant + ".png"));
    }

    @Override
    public Identifier getModelResource(GeoRenderState renderState) {
        return Identifier.of(AdorableHamsterPets.MOD_ID, "hamster_bed");
    }

    @Override
    public Identifier getTextureResource(GeoRenderState renderState) {
        return renderState.getOrDefaultGeckolibData(BED_TEXTURE,
                Identifier.of(AdorableHamsterPets.MOD_ID, "textures/block/hamster_bed_oak.png"));
    }

    @Override
    public Identifier getAnimationResource(HamsterBedBlockEntity animatable) {
        return Identifier.of(AdorableHamsterPets.MOD_ID, "anim_hamster_bed");
    }

}
