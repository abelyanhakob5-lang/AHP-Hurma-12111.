@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo Сборка Adorable Hamster Pets + Hurma для Fabric
echo Minecraft 1.21.11; требуется Java 21 и интернет
echo ================================================
where java >nul 2>nul
if errorlevel 1 (
  echo ОШИБКА: Java не найдена. Установи JDK 21 и повтори запуск.
  pause
  exit /b 1
)
java -version
call gradlew.bat :fabric:build --stacktrace
if errorlevel 1 (
  echo.
  echo СБОРКА НЕ УДАЛАСЬ. Прочитай сообщение об ошибке выше.
  echo Если ошибка связана с services.gradle.org или Maven, проверь интернет/прокси и запусти снова.
  pause
  exit /b 1
)
echo.
echo JAR-файлы, созданные в fabric\build\libs:
if exist "fabric\build\libs\*.jar" (
  dir /b "fabric\build\libs\*.jar"
  echo.
  echo Готовые файлы находятся в папке fabric\build\libs
) else (
  echo Gradle завершился, но JAR в ожидаемой папке не найден. Проверь логи сборки.
)
pause
endlocal
