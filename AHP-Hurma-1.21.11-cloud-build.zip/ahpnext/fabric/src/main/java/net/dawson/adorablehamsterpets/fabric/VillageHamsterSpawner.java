package net.dawson.adorablehamsterpets.fabric;

import com.mojang.serialization.Codec;
import net.dawson.adorablehamsterpets.AdorableHamsterPets;
import net.dawson.adorablehamsterpets.entity.ModEntities;
import net.dawson.adorablehamsterpets.entity.custom.HamsterEntity;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.SpawnReason;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.gen.structure.Structure;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Guarantees at least one hamster per village without ever spawning endlessly.
 *
 * <p>How it avoids duplicates / spam:
 * <ul>
 *   <li>Only the chunk that holds the village's structure START is considered (once per village).</li>
 *   <li>That chunk stores a persistent marker (Fabric data attachment) with the game time of the last
 *       check/spawn. A village is re-checked at most once per {@link #RECHECK_TICKS}.</li>
 *   <li>Before spawning, every hamster (wild or tame) within {@link #SEARCH_RADIUS} blocks is counted;
 *       nothing spawns if one exists.</li>
 *   <li>Work is queued from the chunk-load event and done a few ticks later, at most one village per
 *       tick, so there are no heavy checks per tick.</li>
 * </ul>
 * A tamed hamster that its owner takes away from the village does not count as "gone" until the
 * recheck interval passed; after that one replacement may spawn (bounded, not endless).
 */
public final class VillageHamsterSpawner {

    private static final long RECHECK_TICKS = 24000L * 3; // 3 in-game days
    private static final int SEARCH_RADIUS = 96;
    private static final int DELAY_TICKS = 100;

    private static final AttachmentType<Long> LAST_CHECK = AttachmentRegistry.createPersistent(
            Identifier.of(AdorableHamsterPets.MOD_ID, "village_hamster_last_check"), Codec.LONG);

    private record Pending(ServerWorld world, ChunkPos pos, long dueTick) {}
    private record QueueKey(String dimensionId, long chunkPos) {}

    private static final ArrayDeque<Pending> QUEUE = new ArrayDeque<>();
    private static final Set<QueueKey> QUEUED = new HashSet<>();

    private VillageHamsterSpawner() {}

    public static void init() {
        ServerChunkEvents.CHUNK_LOAD.register((world, chunk) -> onChunkLoad(world, chunk));
        ServerTickEvents.END_SERVER_TICK.register(server -> processQueue());
    }

    private static void onChunkLoad(ServerWorld world, WorldChunk chunk) {
        if (chunk.getStructureStarts().isEmpty()) return;
        Registry<Structure> registry = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
        for (var entry : chunk.getStructureStarts().entrySet()) {
            Identifier id = registry.getId(entry.getKey());
            if (id != null && "minecraft".equals(id.getNamespace()) && id.getPath().startsWith("village_")
                    && entry.getValue().hasChildren()) {
                QueueKey key = new QueueKey(world.getRegistryKey().getValue().toString(), chunk.getPos().toLong());
                if (QUEUED.add(key)) {
                    QUEUE.add(new Pending(world, chunk.getPos(), world.getTime() + DELAY_TICKS));
                }
                return;
            }
        }
    }

    private static void processQueue() {
        // Worlds/dimensions can have different game times. Do not let a not-yet-due entry
        // at the head of the queue block entries whose own world's due time has elapsed.
        Pending p = null;
        Iterator<Pending> iterator = QUEUE.iterator();
        while (iterator.hasNext()) {
            Pending candidate = iterator.next();
            if (candidate.world().getTime() >= candidate.dueTick()) {
                p = candidate;
                iterator.remove();
                break;
            }
        }
        if (p == null) return;
        QUEUED.remove(new QueueKey(p.world().getRegistryKey().getValue().toString(), p.pos().toLong()));

        ServerWorld world = p.world();
        if (!world.isChunkLoaded(p.pos().x, p.pos().z)) return;
        WorldChunk chunk = world.getChunk(p.pos().x, p.pos().z);

        long now = world.getTime();
        Long last = chunk.getAttached(LAST_CHECK);
        if (last != null && now - last < RECHECK_TICKS) return;

        BlockPos center = new BlockPos(p.pos().getCenterX(), world.getBottomY(), p.pos().getCenterZ());
        Box box = new Box(
                center.getX() - SEARCH_RADIUS, world.getBottomY(), center.getZ() - SEARCH_RADIUS,
                center.getX() + SEARCH_RADIUS + 1, world.getTopY(), center.getZ() + SEARCH_RADIUS + 1);
        boolean hasHamster = !world.getEntitiesByType(ModEntities.HAMSTER.get(), box, e -> true).isEmpty();

        if (hasHamster) {
            chunk.setAttached(LAST_CHECK, now);
            return;
        }

        BlockPos spawn = findSafeSpawn(world, p.pos());
        if (spawn == null) {
            // Do not mark the village as handled when its start chunk has no safe surface.
            // A later chunk-load event can retry instead of leaving the village hamster-less for 3 days.
            return;
        }

        HamsterEntity hamster = ModEntities.HAMSTER.get().spawn(world, spawn, SpawnReason.STRUCTURE);
        if (hamster != null) {
            hamster.setPersistent();
            chunk.setAttached(LAST_CHECK, now);
        }
    }

    /** Finds a safe surface position inside the village-start chunk rather than blindly using its center. */
    private static BlockPos findSafeSpawn(ServerWorld world, ChunkPos chunkPos) {
        int startX = chunkPos.getStartX();
        int startZ = chunkPos.getStartZ();
        // Start near the middle, then cover the rest of the chunk in a stable scan.
        for (int radius = 0; radius <= 8; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    int x = startX + 8 + dx;
                    int z = startZ + 8 + dz;
                    int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                    BlockPos feet = new BlockPos(x, y, z);
                    BlockPos head = feet.up();
                    BlockPos ground = feet.down();
                    if (!world.getFluidState(feet).isEmpty() || !world.getFluidState(head).isEmpty()) continue;
                    if (!world.getBlockState(ground).isSolidBlock(world, ground)) continue;
                    if (!world.getBlockState(feet).getCollisionShape(world, feet).isEmpty()) continue;
                    if (!world.getBlockState(head).getCollisionShape(world, head).isEmpty()) continue;
                    return feet;
                }
            }
        }
        return null;
    }
}
