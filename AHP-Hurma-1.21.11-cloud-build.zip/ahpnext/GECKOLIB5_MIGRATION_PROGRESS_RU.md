# GeckoLib 5 migration work — 1.21.11

This is an intermediate source patch, not a compiled mod.

## Changed in this round
- Converted `RedstoneFeverEyesRenderLayer` from the old entity/buffer render callback to GeckoLib 5's render-state model: `addRenderData(...)` captures the redstone-fever flag, and `submitRenderTask(...)` submits an emissive eye pass.
- Changed `HamsterRenderer` to use the 3-parameter GeckoLib 5 renderer generic and the `withRenderLayer(...)` registration method.
- Started migrating dynamic hamster texture selection to render-state data (`DataTicket<Identifier>`), so the render submission does not need to access the live entity.
- Fixed a malformed literal `\\n` accidentally inserted between imports in `HamsterRenderer.java`, and added the `LivingEntityRenderState` import required by the new renderer generic.
- Ported `HamsterModel`'s procedural bone adjustments from the removed `setCustomAnimations` / `getAnimationProcessor()` path to GeckoLib 5 `BoneSnapshots` and `adjustModelBonesForRender`. The model now stores the current hamster in a render-state ticket; the renderer delegates bone adjustments through the new hook.
- Moved bone-matrix tracking setup from the old `preRender(...)` override to `preRenderPass(...)`.

## Known remaining blockers
This source tree is **not build-ready yet**. `HamsterRenderer` still contains old GeckoLib 4/old Minecraft renderer hooks, notably entity-based `render(...)`, `preRender(...)`, and `renderFinal(...)`; these must be migrated together with passenger bone attachment, mouth-held item, particle and sound keyframes. Removed the old `preRender(...)` override after moving bone tracking to `preRenderPass(...)`. `HamsterRenderer` still contains old entity-based `render(...)` and `renderFinal(...)` methods, including passenger bone attachment, mouth-held item, particle and sound keyframes; these must be migrated together to render-state submission. The procedural model migration is only source-level and has not been compiler-verified; performance mode currently applies to the set of named custom bones rather than enumerating every baked bone. The bed renderers also still need a compiler-verified review of their new signatures. These are intentionally listed rather than hidden.

## Verification
Only source-level edits were made. No successful Gradle compile or in-game test is claimed. The network failure preventing Gradle distribution/dependency resolution remains a separate environment blocker.


## Дополнительный проход: текстуры кроваток (12.10.2026)

- Перенёс выбор текстуры блока-кроватки в `HamsterBedModel.addAdditionalStateData(...)`: вариант древесины передаётся через GeckoLib 5 `DataTicket`, а `getTextureResource(...)` читает render state.
- Аналогично перенёс текстуру предмета-кроватки в `HamsterBedItemModel`; убраны старые renderer overrides `getTextureLocation(animatable)` / `getRenderType(animatable, ...)`, которые относятся к старому рендер API.
- Снимок ZIP проверен на целостность. **Компиляция не подтверждена**: главные блокеры всё ещё остаются в `HamsterRenderer` (старые `preRender`, `render`, `renderFinal`) и `HamsterModel` (старый `setCustomAnimations`/`getAnimationProcessor`). Эти места требуют полноценного переноса на render-state submission GeckoLib 5, а не простого переименования методов.


## Ещё один проход: процедурные кости хомяка (12.10.2026)

- Переведены возрастной масштаб тела/головы, цветы, щёки, шапка, веки, наклон при полёте/падении/плавании и moonwalk на `BoneSnapshots`.
- Удалены обращения к старому `AnimationProcessor` из `HamsterModel`.
- Renderer вызывает новую точку входа `adjustModelBonesForRender(...)`; включение tracking matrices перенесено в `preRenderPass(...)`.
- Важно: это ещё не готовая сборка. Ручной рендер пассажиров/предмета/ключевых звуков и частиц в `HamsterRenderer` остаётся не перенесённым, а полный компиляторный прогон недоступен в этой среде.


## Новый проход: отложенный предмет у носа

Добавлен `HamsterAttachmentRenderLayer`: он снимает копию предмета изо рта в render state и регистрирует отложенную задачу на кости `nose`. Рендер использует `HeldItemRenderer` и `ItemDisplayContext.THIRD_PERSON_RIGHT_HAND` для Minecraft 1.21.11. Старый helper, завязанный на `VertexConsumerProvider`, удалён. Пассажиры пока не восстановлены; аудит специально продолжает помечать эту часть как блокирующую.

## Новый проход: отложенный рендеринг вложений

Реализован `HamsterAttachmentRenderLayer` с отложенными задачами на костях `nose` и `body_child`. Предмет изо рта использует `HeldItemRenderer` и `ItemDisplayContext.THIRD_PERSON_RIGHT_HAND`; пассажиры передаются через `EntityRenderer.getAndUpdateRenderState` и `EntityRenderer.render`. Старые immediate-render helpers удалены. `scripts/audit_geckolib5.py --strict` проходит, однако сборка не стартовала: Gradle Wrapper не может разрешить `services.gradle.org`. Это статически проверенный патч, а не подтверждённый игровой билд.


## Продолжение работ — исправление имени renderer dispatcher
- В `HamsterAttachmentRenderLayer.java` заменён `EntityRenderManager` на Yarn-класс `EntityRenderDispatcher`.
- В `scripts/audit_geckolib5.py` добавлена проверка имён классов рендеринга, чтобы такая несовместимость не проходила статический аудит незамеченной.
- `python scripts/audit_geckolib5.py --strict`: пройдено; 340 Java-файлов, старых маркеров API не найдено.
- Попытка `./gradlew :common:compileJava --no-daemon` не дошла до компиляции: Wrapper не смог получить `https://services.gradle.org/distributions/gradle-8.14-bin.zip` из-за сетевой ошибки TLS/DNS в среде.
- Статический аудит не доказывает компилируемость; запуск в Minecraft не выполнялся.


## Исправление Yarn-имен и отключение двух устаревших render-mixin (12.10.2026)

- По Yarn Javadocs для 1.21.11+build.6 исправлено имя класса на `EntityRenderManager`; метод `MinecraftClient.getEntityRenderDispatcher()` при этом сохраняет старое слово в имени getter.
- Исправлен `HamsterAttachmentRenderLayer` и цели классов в двух старых mixin-файлах.
- `EntityRenderDispatcherMixin` и `BlockEntityRenderDispatcherMixin` исключены из активного `adorablehamsterpets.mixins.json`, поскольку их injections завязаны на немедленный рендеринг `renderShadow` и `render(BlockEntity, VertexConsumerProvider)`, отсутствующий в новой render-state системе. Это предотвращает ошибку обязательного mixin при запуске, но временно отключает эффекты смещения тени хомяка и jiggle блок-сущностей; их нужно перенести на новые queue/state hooks отдельно.
- Проверка строгого аудита выполняется после правки. Компиляция по-прежнему не подтверждена: Gradle distribution недоступен в текущей среде.


## Дополнительная проверка attachment rendering
- Удалён дополнительный ручной поворот пассажира вокруг Y в `HamsterAttachmentRenderLayer`: при прямом вызове `EntityRenderer.render(renderState, ...)` поворот уже применяется из состояния пассажира, поэтому ручной поворот мог давать двойную ротацию.
- Исправлено экранирование регулярного выражения в `scripts/audit_geckolib5.py`; проверка имён Yarn-классов теперь анализирует настоящие import-строки.
- `python3 scripts/audit_geckolib5.py --strict` завершился с кодом 0. Это статическая проверка, не Java-компиляция.
