# Временно отключённые render-mixin

В Minecraft Java 1.21.11 Yarn использует классы `EntityRenderManager` и `BlockEntityRenderManager`, а `MinecraftClient.getEntityRenderDispatcher()` остаётся названием getter-метода.

Старые mixin `EntityRenderDispatcherMixin` и `BlockEntityRenderDispatcherMixin` перехватывают немедленные методы отрисовки (`renderShadow` и `render(BlockEntity, VertexConsumerProvider)`), которые несовместимы с новой системой render state / `OrderedRenderCommandQueue`. Они исключены из `adorablehamsterpets.mixins.json`, чтобы обязательные injections не ломали запуск игры.

**Временная потеря поведения:** смещение тени хомяка при перекате и jiggle-анимация block entities не работают, пока не будут перенесены на актуальные точки расширения рендеринга. Сами классы оставлены в исходниках как материал для миграции, но не загружаются как mixin.

Проверка `python scripts/audit_geckolib5.py --strict` проходит. Это статическая проверка, а не компиляция. Gradle/JAR и запуск Minecraft пока не подтверждены.
